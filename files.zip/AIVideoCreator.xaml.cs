﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using Newtonsoft.Json.Linq;
using Microsoft.Win32;
using SkiaSharp;
using WpfOpenFileDialog = Microsoft.Win32.OpenFileDialog;
using WpfSaveFileDialog = Microsoft.Win32.SaveFileDialog;
using WpfMessageBox = System.Windows.MessageBox;
using WpfApp = System.Windows.Application;
using WpfOrientation = System.Windows.Controls.Orientation;

namespace UltraVideoEditor
{
    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    public partial class AIVideoCreator : Window
    {
        private OllamaClient _ollama;
        private bool _ollamaRunning = false;
        private List<string> _lyricLines;
        private List<TimelineSegment> _segments;
        private string _pixabayApiKey;
        private bool _showLyrics = false;
        private bool _enableTransitionSounds = true;
        private bool _enableAmbientSounds = true;
        private bool _enableVoiceNarration = false;
        private string _selectedTheme = "fun";
        private string _tempVideoFolder;
        private string _ambientAudioPath;
        private string _detectedMood = "neutral";
        private string _detectedContext = "";
        private FreesoundClient _freesound;
        private string _freesoundKey;

        // Keš za tranzicione zvukove - preuzimamo jednom, kopiramo za svaku scenu
        private readonly Dictionary<string, string> _transitionSoundCache = new Dictionary<string, string>();

        private static readonly HttpClient _httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        private CancellationTokenSource _cts;
        private bool _isRunning = false;
        private readonly SemaphoreSlim _apiRateLimiter = new SemaphoreSlim(1, 1);

        private List<string> _universalKeywords = new List<string>
        {
            "children playing in park soft light warm colors",
            "kids running and laughing happy atmosphere",
            "children on swings warm colors",
            "happy kids playing outdoors soft light",
            "children having fun warm colors",
            "kids playing together happy atmosphere"
        };

        private static readonly Dictionary<string, List<string>> _contextKeywords = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
        {
            ["lullaby"] = new List<string> { "baby sleeping peaceful soft light", "toddler sleeping cozy bedroom night", "mother rocking baby to sleep warm light" },
            ["party"] = new List<string> { "children birthday party colorful balloons", "kids celebrating happy confetti", "birthday cake candles children excited" },
            ["love"] = new List<string> { "couple holding hands sunset romantic", "romantic walk park golden hour", "love heart flowers warm colors" },
            ["sad"] = new List<string> { "child alone window rain melancholy", "person looking out rainy window", "melancholy empty bench autumn" },
            ["adventure"] = new List<string> { "child exploring forest adventure", "kids hiking mountains adventure", "children running through field adventure" },
            ["nature"] = new List<string> { "beautiful nature flowers soft light", "meadow flowers butterflies sunlight", "spring flowers garden warm light" },
            ["dance"] = new List<string> { "children dancing joyful colorful", "kids dance class happy movement", "children spinning dancing colorful clothes" },
            ["school"] = new List<string> { "children learning classroom bright", "kids school backpack happy", "children reading books learning" },
            ["animal"] = new List<string> { "cute animals children playing warm", "child playing with dog happy", "kids petting animals farm" },
            ["christmas"] = new List<string> { "christmas tree lights cozy warm", "children christmas gifts excited", "winter holiday family warm lights" },
            ["fun"] = new List<string> { "children playing in park soft light warm colors", "kids running and laughing happy atmosphere", "children on swings warm colors" }
        };

        public AIVideoCreator()
        {
            InitializeComponent();
            Loaded += AIVideoCreator_Loaded;
            _pixabayApiKey = GetPixabayApiKey();
        }

        private async void AIVideoCreator_Loaded(object sender, RoutedEventArgs e)
        {
            AutomationProperties.SetName(this, "AI Video Creator dijalog");
            txtOllamaStatus.Text = "🔍 Provjeravam Ollama...";
            txtOllamaStatus.Foreground = System.Windows.Media.Brushes.Orange;

            _ollama = new OllamaClient();
            _ollamaRunning = await _ollama.IsOllamaRunning();

            if (_ollamaRunning)
            {
                txtOllamaStatus.Text = "✅ Ollama je pokrenuta! AI će automatski generisati priču i ključne riječi.";
                txtOllamaStatus.Foreground = System.Windows.Media.Brushes.LightGreen;
                btnGenerate.IsEnabled = true;
            }
            else
            {
                txtOllamaStatus.Text = "❌ Ollama NIJE pokrenuta! AI neće raditi. Molimo pokrenite Ollama.";
                txtOllamaStatus.Foreground = System.Windows.Media.Brushes.Red;
                btnGenerate.IsEnabled = false;
            }

            InitFreesound();
            txtLyrics.Focus();
        }

        private void InitFreesound()
        {
            _freesoundKey = FreesoundClient.ReadKey();
            if (!string.IsNullOrEmpty(_freesoundKey))
            {
                _freesound = new FreesoundClient(_freesoundKey);
                LogToMainWindow("🔊 Freesound inicijalizovan — ambijentalni zvukovi su aktivni.");
            }
            else
            {
                LogToMainWindow("⚠️ Freesound API ključ nije podešen. Ambijentalni zvukovi neće biti dostupni.");
                _enableAmbientSounds = false;
                if (chkAmbientSounds != null) chkAmbientSounds.IsChecked = false;
                if (chkAmbientSounds != null) chkAmbientSounds.IsEnabled = false;
            }
        }

        private void PromptFreesoundKey()
        {
            var result = WpfMessageBox.Show(
                "Freesound API ključ nije podešen.\n\nFreesound.org je besplatan servis koji pruža visokokvalitetne ambijentalne zvukove.\n\nDa li želiš unijeti Freesound API ključ sada?",
                "🔊 Freesound ambijentalni zvukovi",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                var dlg = new ApiKeyDialog("freesound", "Freesound API ključ\n\n1. Idi na freesound.org\n2. Registruj se (besplatno)\n3. Account → Edit Profile → API Applications\n4. Kreiraj novu aplikaciju i kopiraj API key");

                if (dlg.ShowDialog() == true && !string.IsNullOrEmpty(dlg.ApiKey))
                {
                    FreesoundClient.SaveKey(dlg.ApiKey);
                    _freesoundKey = dlg.ApiKey;
                    _freesound = new FreesoundClient(_freesoundKey);
                    LogToMainWindow("✅ Freesound API ključ sačuvan — ambijentalni zvukovi aktivni!");
                }
            }
        }

        private void btnBrowseLogo_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new WpfOpenFileDialog { Filter = "Slike|*.png;*.jpg;*.jpeg;*.bmp" };
            if (dialog.ShowDialog() == true)
                txtLogoPath.Text = dialog.FileName;
        }

        private void txtLyrics_TextChanged(object sender, TextChangedEventArgs e)
        {
            _lyricLines = txtLyrics.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                                         .Where(l => !string.IsNullOrWhiteSpace(l)).ToList();

            lstKeywords.Items.Clear();
            for (int i = 0; i < _lyricLines.Count; i++)
            {
                var stackPanel = new StackPanel { Orientation = WpfOrientation.Horizontal, Margin = new Thickness(5) };
                stackPanel.Children.Add(new TextBlock { Text = $"{i + 1}. ", Width = 40, Foreground = System.Windows.Media.Brushes.White, VerticalAlignment = VerticalAlignment.Center });
                stackPanel.Children.Add(new TextBlock { Text = _lyricLines[i], Width = 350, Foreground = System.Windows.Media.Brushes.LightGray, TextWrapping = TextWrapping.Wrap, VerticalAlignment = VerticalAlignment.Center });
                stackPanel.Children.Add(new TextBlock { Text = "→ AI će generisati priču...", Width = 300, Foreground = System.Windows.Media.Brushes.Gray, VerticalAlignment = VerticalAlignment.Center });
                lstKeywords.Items.Add(stackPanel);
            }
            btnGenerate.IsEnabled = _lyricLines.Count > 0;
        }

        private async void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = WpfApp.Current.MainWindow as MainWindow;
            if (mainWindow == null) { WpfMessageBox.Show("MainWindow nije dostupan.", "Greška", MessageBoxButton.OK, MessageBoxImage.Error); return; }

            _enableTransitionSounds = chkTransitionSounds.IsChecked == true;
            _enableAmbientSounds = chkAmbientSounds.IsChecked == true;
            _enableVoiceNarration = chkVoiceNarration.IsChecked == true;
            _selectedTheme = (cmbVideoTheme.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "fun";

            LogToMainWindow($"🎬 Postavke: TransitionSounds={_enableTransitionSounds}, AmbientSounds={_enableAmbientSounds}, VoiceNarration={_enableVoiceNarration}, Theme={_selectedTheme}");

            var audioItem = mainWindow.timelineItems.FirstOrDefault(i => i.Type == "Audio");

            double totalDuration;
            bool hasAudio = audioItem != null && audioItem.Duration > 0;

            if (!hasAudio)
            {
                var result = WpfMessageBox.Show("Nema audio fajla na timeline-u.\n\nDa li želite da AI automatski generiše pozadinsku muziku?",
                    "🎵 AI Muzika", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result != MessageBoxResult.Yes)
                {
                    WpfMessageBox.Show("Dodajte audio fajl na timeline (Ctrl+Shift+I) prije kreiranja videa.",
                        "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                AnnounceToUser("AI analizira pjesmu...", 0);
                var tempStoryBoard = await GenerateStoryBoard(_lyricLines, _cts?.Token ?? CancellationToken.None);

                totalDuration = 180;

                AnnounceToUser("AI traži odgovarajuću muziku...", 5);
                string mood = _detectedMood ?? tempStoryBoard?.OverallTheme ?? "happy";
                string aiMusicPath = await DownloadBackgroundMusic(mood, totalDuration, _tempVideoFolder, _cts.Token);

                if (!string.IsNullOrEmpty(aiMusicPath))
                {
                    var newAudioItem = new TimelineItem
                    {
                        Path = aiMusicPath,
                        Duration = 0,
                        Start = 0,
                        End = 0,
                        Name = "🎵 AI generisana muzika",
                        Type = "Audio",
                        Volume = 100,
                        TrackIndex = 1
                    };
                    mainWindow.timelineItems.Add(newAudioItem);

                    totalDuration = await GetAudioDuration(aiMusicPath);
                    newAudioItem.Duration = totalDuration;
                    newAudioItem.End = totalDuration;

                    LogToMainWindow($"🎵 AI generisana muzika dodata, trajanje: {FormatTime(totalDuration)}");
                    audioItem = newAudioItem;
                    hasAudio = true;
                }
                else
                {
                    WpfMessageBox.Show("Nije moguće preuzeti AI muziku. Dodajte audio fajl ručno.",
                        "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            else
            {
                totalDuration = audioItem.Duration;
                if (totalDuration <= 0)
                {
                    WpfMessageBox.Show("Audio fajl ima nepoznato trajanje.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            _lyricLines = txtLyrics.Text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Where(l => !string.IsNullOrWhiteSpace(l)).ToList();
            if (_lyricLines.Count == 0) { WpfMessageBox.Show("Unesite tekst pjesme.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Warning); return; }

            _showLyrics = chkShowLyrics.IsChecked == true;
            _cts = new CancellationTokenSource();
            _isRunning = true;
            btnGenerate.IsEnabled = false;
            btnCancel.Content = "ZAUSTAVI";
            btnGenerate.Content = "🎬 AI kreira priču...";
            prgProgress.Visibility = Visibility.Visible;
            AnnounceToUser($"Audio trajanje: {FormatTime(totalDuration)} ({totalDuration:F1}s). Analiziram {_lyricLines.Count} stihova...", 0);

            try
            {
                await ProcessVideoCreation(audioItem.Path, totalDuration);
            }
            catch (OperationCanceledException) { AnnounceToUser("Operacija je otkazana."); }
            catch (Exception ex) { WpfMessageBox.Show($"Greska: {ex.Message}", "Greska", MessageBoxButton.OK, MessageBoxImage.Error); }
            finally { _isRunning = false; _cts?.Dispose(); _cts = null; btnGenerate.IsEnabled = true; btnGenerate.Content = "KREIRAJ VIDEO"; btnCancel.Content = "OTKAZI"; btnCancel.IsEnabled = true; prgProgress.Visibility = Visibility.Collapsed; txtProgress.Text = ""; }
        }

        #region AI Pipeline - 3 Step Architecture

        private async Task<SongAnalysis> AnalyseSongWithAI(List<string> lyrics, CancellationToken ct)
        {
            string lyricsText = string.Join("\n", lyrics);

            string prompt = $@"Analiziraj ovu pjesmu i odgovori ISKLJUČIVO u JSON formatu.

TEKST PJESME:
{lyricsText}

Odgovori u ovom JSON formatu:
{{
  ""context"": ""[fun/lullaby/party/love/sad/adventure/nature/dance/school/animal/christmas/outdoor/seasons/health]"",
  ""mood"": ""[happy/calm/melancholy/romantic/excited/energetic/upbeat/curious/playful/joyful/peaceful]"",
  ""theme"": ""[jedna rečenica na srpskom: o čemu je pjesma]"",
  ""visual_style"": ""[5-7 engleskih riječi za vizualni stil]"",
  ""main_subject"": ""[dijete/beba/porodica/priroda/životinja]"",
  ""season"": ""[spring/summer/autumn/winter/all/none]"",
  ""setting"": ""[park/bedroom/school/forest/beach/city/home/outdoors/mixed]""
}}";

            try
            {
                LogToMainWindow("🧠 AI analizira cjelokupnu pjesmu...");
                string response = await _ollama.GenerateAsync(prompt, ct: ct);
                string jsonStr = ExtractJson(response);
                if (!string.IsNullOrEmpty(jsonStr))
                {
                    var analysis = Newtonsoft.Json.JsonConvert.DeserializeObject<SongAnalysis>(jsonStr);
                    if (analysis != null)
                    {
                        LogToMainWindow($"🎭 AI analiza: kontekst='{analysis.Context}', mood='{analysis.Mood}', tema='{analysis.Theme}'");
                        return analysis;
                    }
                }
            }
            catch (Exception ex)
            {
                LogToMainWindow($"⚠️ AI analiza nije uspjela ({ex.Message}), koristim keyword detekciju...");
            }

            return FallbackSongAnalysis(lyrics);
        }

        private SongAnalysis FallbackSongAnalysis(List<string> lyrics)
        {
            string allText = string.Join(" ", lyrics).ToLower();
            var scores = new Dictionary<string, int> { ["lullaby"] = 0, ["party"] = 0, ["love"] = 0, ["sad"] = 0, ["adventure"] = 0, ["nature"] = 0, ["dance"] = 0, ["school"] = 0, ["animal"] = 0, ["christmas"] = 0, ["outdoor"] = 0, ["seasons"] = 0, ["health"] = 0, ["fun"] = 1 };

            string[] lullabyW = { "spavaj", "usni", "sni", "laku noć", "uspavanka", "sleep", "lullaby", "goodnight", "moonlight" };
            string[] partyW = { "sretan", "srećan", "rođendan", "baloni", "torta", "birthday", "party", "balloon", "cake", "celebrate" };
            string[] loveW = { "volim", "ljubav", "srce", "draga", "dragi", "love", "heart", "kiss", "hug", "romance" };
            string[] sadW = { "plačem", "suze", "tužan", "tuga", "cry", "tears", "sad", "alone", "lonely", "goodbye" };
            string[] adventW = { "istraži", "avantura", "planina", "šuma", "adventure", "explore", "mountain", "forest", "discover" };
            string[] natureW = { "cvijet", "proljeće", "jesen", "zima", "ljeto", "priroda", "flower", "spring", "autumn", "winter", "summer", "nature" };
            string[] danceW = { "pleši", "igraj", "ples", "ritam", "dance", "dancing", "rhythm", "music", "sing" };
            string[] schoolW = { "škola", "učenje", "knjiga", "učitelj", "school", "learn", "book", "teacher", "class" };
            string[] animalW = { "pas", "maca", "konj", "zec", "ptica", "dog", "cat", "horse", "bunny", "animal" };
            string[] xmasW = { "božić", "nova godina", "snijeg", "jelka", "christmas", "santa", "snow", "holiday", "gift" };
            string[] outdoorW = { "šetaj", "šetnja", "trči", "park", "outdoor", "walk", "run", "playground", "park", "outside" };
            string[] seasonsW = { "proleće", "proljeće", "jesen", "zima", "leto", "ljeto", "spring", "autumn", "fall", "winter", "summer", "seasons" };
            string[] healthW = { "zdravlje", "zdravo", "zdravi", "kretanje", "health", "healthy", "exercise", "active", "fit", "movement" };

            foreach (var w in lullabyW) if (allText.Contains(w)) scores["lullaby"] += 3;
            foreach (var w in partyW) if (allText.Contains(w)) scores["party"] += 3;
            foreach (var w in loveW) if (allText.Contains(w)) scores["love"] += 3;
            foreach (var w in sadW) if (allText.Contains(w)) scores["sad"] += 3;
            foreach (var w in adventW) if (allText.Contains(w)) scores["adventure"] += 2;
            foreach (var w in natureW) if (allText.Contains(w)) scores["nature"] += 1;
            foreach (var w in danceW) if (allText.Contains(w)) scores["dance"] += 2;
            foreach (var w in schoolW) if (allText.Contains(w)) scores["school"] += 2;
            foreach (var w in animalW) if (allText.Contains(w)) scores["animal"] += 2;
            foreach (var w in xmasW) if (allText.Contains(w)) scores["christmas"] += 4;
            foreach (var w in outdoorW) if (allText.Contains(w)) scores["outdoor"] += 2;
            foreach (var w in seasonsW) if (allText.Contains(w)) scores["seasons"] += 2;
            foreach (var w in healthW) if (allText.Contains(w)) scores["health"] += 2;

            string ctx = scores.OrderByDescending(kv => kv.Value).First().Key;
            string mood = ctx switch { "lullaby" => "calm", "sad" => "melancholy", "love" => "romantic", "party" => "excited", "adventure" => "energetic", "dance" => "upbeat", "christmas" => "joyful", "animal" => "playful", "school" => "curious", "nature" => "peaceful", "outdoor" => "happy", _ => "happy" };

            string season = "none";
            if (allText.Contains("proleć") || allText.Contains("spring")) season = "spring";
            else if (allText.Contains("jesen") || allText.Contains("autumn")) season = "autumn";
            else if (allText.Contains("zima") || allText.Contains("winter")) season = "winter";
            else if (allText.Contains("leto") || allText.Contains("summer")) season = "summer";
            else if (scores["seasons"] >= 2) season = "all";

            return new SongAnalysis
            {
                Context = ctx,
                Mood = mood,
                Theme = "Dječija pjesma",
                VisualStyle = "warm colors soft light natural outdoor",
                MainSubject = "children",
                Season = season,
                Setting = ctx == "outdoor" || ctx == "seasons" || ctx == "health" ? "outdoors" : "mixed"
            };
        }

        // MODIFICIRANA METODA: Agresivniji prompt za literalnu ilustraciju akcija
        private async Task<List<SceneKeywords>> GenerateKeywordsPerLyric(List<string> lyrics, SongAnalysis analysis, CancellationToken ct)
        {
            var results = new List<SceneKeywords>();
            int total = lyrics.Count;

            LogToMainWindow($"🎬 Generiram vizualne keywords za {total} stihova (LITERAL ACTION SYNC)...");

            int batchSize = 4;
            for (int i = 0; i < total; i += batchSize)
            {
                ct.ThrowIfCancellationRequested();
                var batch = lyrics.Skip(i).Take(batchSize).ToList();
                int batchStart = i;

                string batchText = string.Join("\n", batch.Select((l, idx) => $"{batchStart + idx + 1}. {l}"));

                // AGRESIVNI PROMPT sa fokusom na bukvalnu ilustraciju akcije, NE pejzaže!
                string prompt = $@"VIDEO REŽIJA – LITERALNA ILUSTRACIJA – NEMA PEJZAŽA BEZ AKCIJE

Pravilo: ŠTA STIH KAŽE, TO SE VIDEO VIDI. NEMA METAFORA. NEMA GENERIČKIH PRIZORA.

Stihovi pjesme (tema: {analysis.Theme}, stil: {analysis.VisualStyle}):

{batchText}

Za SVAKI stih, navedi tačno ono što se bukvalno događa u tekstu:

Ako stih kaže:
- ""trči"" → video MORA biti: children running
- ""skače"" → video MORA biti: child jumping
- ""smeje se"" → video MORA biti: children laughing
- ""šeće se"" → video MORA biti: child walking
- ""igra loptu"" → video MORA biti: children playing ball
- ""drži se za ruke"" → video MORA biti: holding hands walking
- ""jede sladoled"" → video MORA biti: child eating ice cream
- ""vozi bicikl"" → video MORA biti: child riding bicycle

ZABRANJENO:
- generički ""happy child in park"" bez jasne akcije
- pejzaži bez djece (šume, polja, cvijeće) – OSLIM ako tekst to ne nalaže
- apstraktne scene

DOZVOLJENO:
- SPECIFIČNA radnja koja se pominje u stihu
- LICA koja pokazuju emociju navedenu u stihu
- SEZONSKE elemente SAMO ako tekst pominje godišnje doba

Odgovori ISKLJUČIVO JSON:
[
  {{""line"": {batchStart + 1}, ""keywords"": ""konkretna akcija + subjekt + detalj"", ""ambient"": ""zvuk koji odgovara sceni""}},
  {{""line"": {batchStart + 2}, ""keywords"": ""..."", ""ambient"": ""...""}}
]";

                try
                {
                    AnnounceToUser($"AI analizira stihove {i + 1}-{Math.Min(i + batchSize, total)} (literal akcija)...", 5 + (i * 20 / total));
                    string response = await _ollama.GenerateAsync(prompt, ct: ct);
                    string jsonStr = ExtractJson(response, isArray: true);

                    if (!string.IsNullOrEmpty(jsonStr))
                    {
                        var batchResults = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SceneKeywords>>(jsonStr);
                        if (batchResults != null && batchResults.Count > 0)
                        {
                            // Validacija: ignoriši template tekst koji AI vrati bukvalno
                            foreach (var r in batchResults)
                            {
                                bool isTemplate = string.IsNullOrEmpty(r.Keywords) ||
                                    r.Keywords.Contains("konkretna akcija") ||
                                    r.Keywords.Contains("subjekt + detalj") ||
                                    r.Keywords == "..." ||
                                    r.Keywords.Length < 3;
                                if (isTemplate)
                                {
                                    // Popravi lokalno
                                    int lyricIdx = r.Line - batchStart - 1;
                                    if (lyricIdx >= 0 && lyricIdx < batch.Count)
                                    {
                                        r.Keywords = GenerateKeywordsFromLyric(batch[lyricIdx], analysis);
                                        r.Ambient  = InferAmbientFromLyric(batch[lyricIdx], analysis.Context);
                                    }
                                }
                            }
                            results.AddRange(batchResults);
                            foreach (var r in batchResults)
                                LogToMainWindow($"   Stih {r.Line}: akcija='{r.Keywords}', zvuk='{r.Ambient}'");
                            continue;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogToMainWindow($"⚠️ Keywords batch greška: {ex.Message}");
                }

                // Fallback: lokalna detekcija akcije iz teksta
                foreach (var (lyric, idx) in batch.Select((l, idx) => (l, idx)))
                {
                    results.Add(new SceneKeywords
                    {
                        Line = batchStart + idx + 1,
                        Keywords = GenerateKeywordsFromLyric(lyric, analysis),
                        Ambient = InferAmbientFromLyric(lyric, analysis.Context)
                    });
                }
            }

            while (results.Count < total)
            {
                int missing = results.Count;
                results.Add(new SceneKeywords
                {
                    Line = missing + 1,
                    Keywords = GenerateKeywordsFromLyric(lyrics[missing], analysis),
                    Ambient = InferAmbientFromLyric(lyrics[missing], analysis.Context)
                });
            }

            return results;
        }

        private string GenerateKeywordsFromLyric(string lyric, SongAnalysis analysis)
        {
            string lower = lyric.ToLower();
            string style = analysis.VisualStyle ?? "warm colors soft light";

            // LITERALNA MAPIRANJA AKCIJA:
            if (lower.Contains("šetaj") || lower.Contains("šetnja")) return $"child walking park {style}";
            if (lower.Contains("trči") || lower.Contains("trka")) return $"children running active {style}";
            if (lower.Contains("smej") || lower.Contains("blistaj")) return $"children laughing happy faces {style}";
            if (lower.Contains("igraj") || lower.Contains("igra")) return $"children playing joyful {style}";
            if (lower.Contains("pleši")) return $"children dancing movement {style}";
            if (lower.Contains("skoči")) return $"child jumping happy {style}";
            if (lower.Contains("uzmi") || lower.Contains("nosi")) return $"child carrying {style}";
            if (lower.Contains("upoznaj")) return $"child exploring {style}";

            // Sezone samo ako su pomenute
            if (lower.Contains("proleć") || lower.Contains("proljeć")) return $"spring flowers blooming child playing {style}";
            if (lower.Contains("jesen")) return $"autumn leaves falling child walking {style}";
            if (lower.Contains("zima") || lower.Contains("sneg")) return $"winter snow child playing outdoor {style}";
            if (lower.Contains("leto") || lower.Contains("ljeto")) return $"summer beach child swimming {style}";

            // Aktivnosti
            if (lower.Contains("sladoled")) return $"child eating ice cream summer {style}";
            if (lower.Contains("čokolada")) return $"child drinking hot chocolate winter {style}";
            if (lower.Contains("parkić") || lower.Contains("park")) return $"child playing park playground {style}";
            if (lower.Contains("mama") || lower.Contains("tata")) return $"family walking together park {style}";

            return analysis.Context switch
            {
                "outdoor" => $"child outdoor activity playing {style}",
                "dance" => $"children dancing joyful {style}",
                "lullaby" => $"child sleeping peaceful bedroom soft light",
                "party" => $"child celebrating birthday party",
                _ => $"child playing outdoor happy {style}"
            };
        }

        private string InferAmbientFromLyric(string lyric, string context)
        {
            // PRINCIP: Literal sync — čitam stih i vraćam TAČAN zvuk koji odgovara.
            // Npr. "ptice pjevaju" → "birds chirping", "reka teče" → "stream flowing".
            // KONTEKSTUALNA KOREKCIJA: ako je pjesma vesela/dječija, "zimski" stihovi
            // dobijaju VESELE zimske zvukove (djeca u snijegu), ne zastrašujući vjetar.
            string lower = lyric.ToLower();
            bool isJoyfulContext = context is "outdoor" or "health" or "fun" or "party"
                                             or "dance" or "seasons" or "animal" or "school";

            // ══════════════════════════════════════════════════════════════
            // 1. NAJSPECIFIČNIJI ZVUCI — direktno iz teksta
            // ══════════════════════════════════════════════════════════════

            // Ptice — svako pominjanje
            if (lower.Contains("ptic") || lower.Contains("cvrkut") ||
                lower.Contains("pjev") || lower.Contains("lastavic") ||
                lower.Contains("vrabac") || lower.Contains("slavuj"))
                return "birds chirping";

            // Voda — reka, potok, bujica
            if (lower.Contains("reka") || lower.Contains("rijeka") ||
                lower.Contains("potok") || lower.Contains("bujica") ||
                lower.Contains("izvor") || lower.Contains("voda teč"))
                return "stream flowing";

            // More / plaža / talasi
            if (lower.Contains("more") || lower.Contains("plaža") ||
                lower.Contains("talas") || lower.Contains("obala") ||
                lower.Contains("brod") || lower.Contains("ocean"))
                return "ocean waves";

            // Vjetar / povjetarac
            if (lower.Contains("vetar") || lower.Contains("vjetar") ||
                lower.Contains("povjetarac") || lower.Contains("duva"))
                return isJoyfulContext ? "gentle breeze outdoor" : "wind outdoor";

            // Kiša
            if (lower.Contains("kiša") || lower.Contains("pada kiša") ||
                lower.Contains("kaplja") || lower.Contains("mokro"))
                return "gentle rain";

            // Grmljavina / oluja
            if (lower.Contains("grmljavina") || lower.Contains("oluja") ||
                lower.Contains("munja") || lower.Contains("grom"))
                return "thunder storm";

            // Šuma / drveće / lišće
            if (lower.Contains("šuma") || lower.Contains("suma") ||
                lower.Contains("drveć") || lower.Contains("grana") ||
                lower.Contains("lisće") || lower.Contains("lišće") ||
                lower.Contains("šušti"))
                return "forest birds nature";

            // ══════════════════════════════════════════════════════════════
            // 2. GODIŠNJA DOBA — s kontekstualnom korekcijom
            // ══════════════════════════════════════════════════════════════

            // Proljeće
            if (lower.Contains("proljeć") || lower.Contains("proleć") ||
                lower.Contains("cvijet") || lower.Contains("cvece") ||
                lower.Contains("bujanje") || lower.Contains("procvat"))
                return "birds chirping spring";

            // Ljeto / sunce / toplo
            if (lower.Contains("leto") || lower.Contains("ljeto") ||
                lower.Contains("sunce") || lower.Contains("toplo") ||
                lower.Contains("vrućina") || lower.Contains("cvrčci"))
                return "summer nature crickets";

            // Jesen / lišće opada
            if (lower.Contains("jesen") || lower.Contains("lišće pada") ||
                lower.Contains("opada") || lower.Contains("zlatno") ||
                lower.Contains("žuto lišće"))
                return "autumn leaves rustling";

            // Zima / snijeg — KOREKCIJA: vesele pjesme dobijaju zvukove djece u snijegu
            // ne zastrašujući zimski vjetar
            if (lower.Contains("zima") || lower.Contains("sneg") ||
                lower.Contains("snijeg") || lower.Contains("mraz") ||
                lower.Contains("led") || lower.Contains("mećava"))
            {
                return isJoyfulContext
                    ? "children playing snow"   // Djeca se igraju u snijegu
                    : "winter wind snow";        // Samo za tužne/mračne kontekste
            }

            // Specifična zimska odjeća — samo označava zimu, ne treba strašan vjetar
            if (lower.Contains("čizme") || lower.Contains("rukavice") ||
                lower.Contains("skafander") || lower.Contains("kapu") ||
                lower.Contains("šal") || lower.Contains("kaput"))
                return isJoyfulContext
                    ? "children playing snow"
                    : "winter wind snow";

            // ══════════════════════════════════════════════════════════════
            // 3. AKTIVNOSTI — zvukovi koji prate radnju
            // ══════════════════════════════════════════════════════════════

            // Trčanje / skakanje / aktivan sport
            if (lower.Contains("trči") || lower.Contains("trčanje") ||
                lower.Contains("skoči") || lower.Contains("skači") ||
                lower.Contains("blistaj") || lower.Contains("juri"))
                return "children playing outdoor";

            // Smijeh / radost / veselje
            if (lower.Contains("smej") || lower.Contains("smije") ||
                lower.Contains("smeh") || lower.Contains("veselo") ||
                lower.Contains("haha") || lower.Contains("raduj"))
                return "children laughing";

            // Šetnja / hodanje (tiho, opušteno)
            if (lower.Contains("šetaj") || lower.Contains("šetnja") ||
                lower.Contains("hodaj") || lower.Contains("korak") ||
                lower.Contains("prošetaj") || lower.Contains("idi"))
                return "park ambience footsteps";

            // Igranje (opšte)
            if (lower.Contains("igraj") || lower.Contains("igra ") ||
                lower.Contains("igrice") || lower.Contains("zabav"))
                return "children playing outdoor";

            // ══════════════════════════════════════════════════════════════
            // 4. MJESTA — zvuci okoline
            // ══════════════════════════════════════════════════════════════

            // Park / playground
            if (lower.Contains("park") || lower.Contains("parkić") ||
                lower.Contains("klackalica") || lower.Contains("ljuljaška") ||
                lower.Contains("tobogan") || lower.Contains("peskovnik"))
                return "park ambience birds";

            // Grad / ulica
            if (lower.Contains("grad") || lower.Contains("ulica") ||
                lower.Contains("sokak") || lower.Contains("centar"))
                return "city park ambience";

            // Kuća / dom / unutra
            if (lower.Contains("kuća") || lower.Contains("kuca") ||
                lower.Contains("dom") || lower.Contains("soba") ||
                lower.Contains("unutra") || lower.Contains("topla"))
                return "home warmth fireplace";

            // Planina / vis
            if (lower.Contains("planina") || lower.Contains("vrh") ||
                lower.Contains("klisura") || lower.Contains("pećina"))
                return "mountain wind birds";

            // ══════════════════════════════════════════════════════════════
            // 5. HRANA / PIĆE — zvuci koji asociraju na ugodan ambijent
            // ══════════════════════════════════════════════════════════════

            if (lower.Contains("sladoled"))
                return "summer park children";

            if (lower.Contains("čaj") || lower.Contains("kakao") ||
                lower.Contains("čokolada") || lower.Contains("topli napit"))
                return "home warmth fireplace";

            if (lower.Contains("torta") || lower.Contains("kolač") ||
                lower.Contains("slatkiš"))
                return "children birthday party";

            // ══════════════════════════════════════════════════════════════
            // 6. ŽIVOTINJE — direktni zvuci
            // ══════════════════════════════════════════════════════════════

            if (lower.Contains("pas") || lower.Contains("kučić") ||
                lower.Contains("štene"))
                return "dog playing outdoor";

            if (lower.Contains("maca") || lower.Contains("mačka") ||
                lower.Contains("mače"))
                return "cat purring";

            if (lower.Contains("konj") || lower.Contains("konjanik"))
                return "horse hooves";

            if (lower.Contains("pčela") || lower.Contains("leptir") ||
                lower.Contains("buba"))
                return "summer meadow insects";

            if (lower.Contains("zec") || lower.Contains("vjeverica"))
                return "forest animals gentle";

            // ══════════════════════════════════════════════════════════════
            // 7. PORODICA / EMOCIJE — topli ambijentalni zvuci
            // ══════════════════════════════════════════════════════════════

            if (lower.Contains("mama") || lower.Contains("majka") ||
                lower.Contains("tata") || lower.Contains("otac"))
                return "park ambience family";

            if (lower.Contains("baka") || lower.Contains("deka") ||
                lower.Contains("porodic"))
                return "home warmth gentle";

            if (lower.Contains("drugar") || lower.Contains("prijatelj") ||
                lower.Contains("zajedno") || lower.Contains("svi"))
                return "children group playing";

            // ══════════════════════════════════════════════════════════════
            // 8. SPAVANJE / NOĆ / MIROVANJE
            // VAŽNO: Kontekstualna korekcija — u veseloj dječijoj pjesmi "noći"
            // znači "jutro poslije noći" (ustaj, šetaj), ne noćna scena.
            // ══════════════════════════════════════════════════════════════

            if (lower.Contains("spavaj") || lower.Contains("zaspi") ||
                lower.Contains("laku noć") || lower.Contains("usni") ||
                lower.Contains("san ") || lower.Contains("sanjaj"))
                return isJoyfulContext ? "park birds outdoor" : "lullaby music box";

            // "noći" u kontekstu "poslije noći" / "jutro" → park zvuci za vesele pjesme
            if (lower.Contains("noć") || lower.Contains("zvijezd") ||
                lower.Contains("mesec") || lower.Contains("tišina"))
                return isJoyfulContext ? "morning birds outdoor" : "night crickets gentle";

            // ══════════════════════════════════════════════════════════════
            // 9. ZDRAVLJE / SPORT / AKTIVNOST
            // ══════════════════════════════════════════════════════════════

            if (lower.Contains("zdravo") || lower.Contains("zdravlje") ||
                lower.Contains("jako") || lower.Contains("snažno"))
                return "park ambience birds";

            // ══════════════════════════════════════════════════════════════
            // 10. FALLBACK PO KONTEKSTU PJESME
            // ══════════════════════════════════════════════════════════════
            return context switch
            {
                "lullaby"    => "lullaby music box",
                "outdoor"    => "park birds outdoor",
                "health"     => "park birds outdoor",
                "nature"     => "forest stream birds",
                "adventure"  => "forest birds outdoor",
                "sad"        => "gentle rain",
                "party"      => "children laughing party",
                "christmas"  => "home warmth fireplace",
                "animal"     => "forest animals nature",
                "seasons"    => "birds chirping nature",
                "dance"      => "children playing outdoor",
                "school"     => "children playground",
                "love"       => "park birds gentle",
                "fun"        => "park birds outdoor",
                _            => "birds chirping nature"
            };
        }

        private string ExtractJson(string text, bool isArray = false)
        {
            if (string.IsNullOrEmpty(text)) return null;
            text = System.Text.RegularExpressions.Regex.Replace(text, @"```json|```", "").Trim();
            try
            {
                if (isArray)
                {
                    int start = text.IndexOf('[');
                    int end = text.LastIndexOf(']');
                    if (start >= 0 && end > start) return text.Substring(start, end - start + 1);
                }
                else
                {
                    int start = text.IndexOf('{');
                    int end = text.LastIndexOf('}');
                    if (start >= 0 && end > start) return text.Substring(start, end - start + 1);
                }
            }
            catch { }
            return null;
        }

        private void DetectContextFromLyrics(List<string> lyrics)
        {
            string allText = string.Join(" ", lyrics).ToLower();
            var scores = new Dictionary<string, int> { ["lullaby"] = 0, ["party"] = 0, ["love"] = 0, ["sad"] = 0, ["adventure"] = 0, ["nature"] = 0, ["dance"] = 0, ["school"] = 0, ["animal"] = 0, ["christmas"] = 0, ["fun"] = 1 };

            string[] lullabyWords = { "spavaj", "usni", "sni", "laku noć", "uspavanka", "sleep", "lullaby", "goodnight", "moonlight" };
            string[] partyWords = { "sretan", "srećan", "rođendan", "baloni", "torta", "birthday", "party", "balloon", "cake", "celebrate" };
            string[] loveWords = { "volim", "ljubav", "srce", "draga", "dragi", "love", "heart", "kiss", "hug", "romance" };
            string[] sadWords = { "plačem", "suze", "tužan", "tuga", "cry", "tears", "sad", "alone", "lonely", "goodbye" };
            string[] adventureWords = { "istraži", "avantura", "planina", "šuma", "adventure", "explore", "mountain", "forest", "discover" };
            string[] natureWords = { "cvijet", "proljeće", "jesen", "zima", "ljeto", "priroda", "flower", "spring", "autumn", "winter", "summer", "nature" };
            string[] danceWords = { "pleši", "igraj", "ples", "ritam", "dance", "dancing", "rhythm", "music", "sing" };
            string[] schoolWords = { "škola", "učenje", "knjiga", "učitelj", "school", "learn", "book", "teacher", "class" };
            string[] animalWords = { "pas", "maca", "konj", "zec", "ptica", "dog", "cat", "horse", "bunny", "animal" };
            string[] xmasWords = { "božić", "nova godina", "snijeg", "jelka", "christmas", "santa", "snow", "holiday", "gift" };

            foreach (var w in lullabyWords) if (allText.Contains(w)) scores["lullaby"] += 3;
            foreach (var w in partyWords) if (allText.Contains(w)) scores["party"] += 3;
            foreach (var w in loveWords) if (allText.Contains(w)) scores["love"] += 3;
            foreach (var w in sadWords) if (allText.Contains(w)) scores["sad"] += 3;
            foreach (var w in adventureWords) if (allText.Contains(w)) scores["adventure"] += 2;
            foreach (var w in natureWords) if (allText.Contains(w)) scores["nature"] += 1;
            foreach (var w in danceWords) if (allText.Contains(w)) scores["dance"] += 2;
            foreach (var w in schoolWords) if (allText.Contains(w)) scores["school"] += 2;
            foreach (var w in animalWords) if (allText.Contains(w)) scores["animal"] += 2;
            foreach (var w in xmasWords) if (allText.Contains(w)) scores["christmas"] += 4;

            string detected = scores.OrderByDescending(kv => kv.Value).First().Key;
            _detectedContext = detected;

            _detectedMood = detected switch
            {
                "lullaby" => "calm",
                "sad" => "melancholy",
                "love" => "romantic",
                "party" => "excited",
                "adventure" => "energetic",
                "dance" => "upbeat",
                "christmas" => "joyful",
                "animal" => "playful",
                "school" => "curious",
                "nature" => "peaceful",
                _ => "happy"
            };

            if (_contextKeywords.TryGetValue(detected, out var contextList))
                _universalKeywords = new List<string>(contextList);

            LogToMainWindow($"🎭 Detektovan kontekst pjesme: '{detected}', raspoloženje: '{_detectedMood}'");
        }

        private async Task<StoryBoard> GenerateStoryBoard(List<string> lyrics, CancellationToken ct)
        {
            var analysis = await AnalyseSongWithAI(lyrics, ct);
            _detectedContext = analysis.Context ?? "fun";
            _detectedMood = analysis.Mood ?? "happy";

            if (_contextKeywords.TryGetValue(_detectedContext, out var ctxList))
                _universalKeywords = new List<string>(ctxList);

            var perLyricKeywords = await GenerateKeywordsPerLyric(lyrics, analysis, ct);

            var scenes = new List<StoryScene>();
            for (int i = 0; i < lyrics.Count; i++)
            {
                var kw = perLyricKeywords.FirstOrDefault(k => k.Line == i + 1);
                string keywords = kw?.Keywords ?? GenerateKeywordsFromLyric(lyrics[i], analysis);
                string ambient = kw?.Ambient ?? InferAmbientFromLyric(lyrics[i], analysis.Context);
                // Normalizuj AI ambient opis na naše mapiranje
                // AI može vratiti slobodan tekst ("zvuk kućanstva ili restorana") —
                // to mapiramo na konkretne Freesound querije
                ambient = NormalizeAmbientFromAI(ambient, lyrics[i], analysis.Context ?? "outdoor");
                int energy = CalculateEnergy(i, lyrics.Count, analysis.Context);

                scenes.Add(new StoryScene
                {
                    SceneNumber = i + 1,
                    Description = lyrics[i].Length > 60 ? lyrics[i].Substring(0, 57) + "..." : lyrics[i],
                    Emotion = analysis.Mood ?? "happy",
                    Energy = energy,
                    Characters = analysis.MainSubject ?? "children",
                    Action = ExtractActionFromLyric(lyrics[i]),
                    Location = analysis.Setting ?? "outdoor",
                    Keywords = keywords,
                    AmbientSound = ambient
                });
            }

            string overallTheme = analysis.Theme ?? (_detectedContext switch
            {
                "lullaby" => "Mirna uspavanka",
                "party" => "Vesela proslava",
                "love" => "Ljubavna priča",
                "sad" => "Emotivno putovanje",
                "adventure" => "Uzbudljiva avantura",
                "dance" => "Veseli ples",
                "christmas" => "Čarobni Božić",
                "outdoor" => "Aktivni život na otvorenom",
                "seasons" => "Ljepota godišnjih doba",
                "health" => "Zdravo i aktivno dijete",
                _ => "Vesela dječija pjesma"
            });

            LogToMainWindow($"✅ Story board kreiran: {scenes.Count} scena za temu: '{overallTheme}'");
            return new StoryBoard { Scenes = scenes, MainCharacter = analysis.MainSubject ?? "Happy child", OverallTheme = overallTheme };
        }

        private int CalculateEnergy(int index, int total, string context)
        {
            if (context == "lullaby") return 1;
            if (context == "sad") return index < 2 ? 1 : 2;
            double pos = (double)index / total;
            if (pos < 0.15) return 2;
            if (pos < 0.30) return 3;
            if (pos >= 0.60 && pos < 0.80) return 5;
            if (pos >= 0.85) return 2;
            return 4;
        }

        private string ExtractActionFromLyric(string lyric)
        {
            string lower = lyric.ToLower();
            if (lower.Contains("šetaj") || lower.Contains("šetnja")) return "walking";
            if (lower.Contains("trči")) return "running";
            if (lower.Contains("smej") || lower.Contains("blistaj")) return "laughing";
            if (lower.Contains("igraj")) return "playing";
            if (lower.Contains("pleši")) return "dancing";
            if (lower.Contains("spavaj")) return "sleeping";
            if (lower.Contains("skoči")) return "jumping";
            if (lower.Contains("uzmi")) return "carrying";
            if (lower.Contains("upoznaj")) return "exploring";
            return "enjoying";
        }

        private bool ValidateStoryBoard(StoryBoard storyBoard)
        {
            if (storyBoard?.Scenes == null || storyBoard.Scenes.Count < 3)
            {
                LogToMainWindow("❌ Validacija neuspješna: Nema dovoljno scena");
                return false;
            }

            var scenes = storyBoard.Scenes;
            bool valid = true;

            bool requiresPeak = _detectedContext != "lullaby" && _detectedContext != "sad";

            if (requiresPeak)
            {
                bool hasPeak = scenes.Any(s => s.Energy >= 4);
                if (!hasPeak)
                {
                    LogToMainWindow("⚠️ Nema scene sa visokom energijom (peak)");
                    valid = false;
                }
            }

            if (_detectedContext == "lullaby")
            {
                bool allCalm = scenes.All(s => s.Energy <= 2);
                if (!allCalm)
                {
                    LogToMainWindow("⚠️ Uspavanka ima scenu sa previsoko energijom");
                    valid = false;
                }
            }

            if (valid)
                LogToMainWindow("✅ Story board validacija uspješna!");
            else
                LogToMainWindow("❌ Story board validacija neuspješna");

            return valid;
        }

        private StoryBoard ParseStoryBoard(string response)
        {
            try
            {
                int start = response.IndexOf('[');
                int end = response.LastIndexOf(']');
                if (start >= 0 && end > start)
                {
                    string json = response.Substring(start, end - start + 1);
                    json = System.Text.RegularExpressions.Regex.Replace(json, @"\]\s*,\s*\[", "],[");

                    if (!json.TrimStart().StartsWith("[") && json.Contains("{"))
                    {
                        json = $"[{json}]";
                    }

                    var scenes = Newtonsoft.Json.JsonConvert.DeserializeObject<List<StoryScene>>(json);

                    if (scenes != null && scenes.Count > 0)
                    {
                        LogToMainWindow($"✅ Uspješno parsirano {scenes.Count} scena");

                        string overallTheme = _detectedContext switch
                        {
                            "lullaby" => "Peaceful bedtime story",
                            "party" => "Joyful birthday celebration",
                            "love" => "Romantic love journey",
                            "sad" => "Emotional reflection",
                            "adventure" => "Exciting exploration",
                            "dance" => "Joyful dance story",
                            "christmas" => "Magical Christmas story",
                            "animal" => "Animal friends adventure",
                            "school" => "Learning and discovery",
                            "nature" => "Beautiful nature journey",
                            _ => _selectedTheme == "calm" ? "Peaceful adventure" :
                                 _selectedTheme == "educational" ? "Learning adventure" :
                                 _selectedTheme == "action" ? "Exciting adventure" : "Fun adventure"
                        };

                        return new StoryBoard
                        {
                            Scenes = scenes,
                            MainCharacter = scenes[0]?.Characters ?? "Happy child",
                            OverallTheme = overallTheme
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                LogToMainWindow($"❌ Greška pri parsiranju: {ex.Message}");
            }

            return CreateFallbackStoryBoard();
        }

        private StoryBoard CreateFallbackStoryBoard()
        {
            LogToMainWindow("🔄 Koristim fallback story board");
            var scenes = new List<StoryScene>();

            string mainCharacter = _detectedContext switch
            {
                "lullaby" => "Sleeping baby in cozy crib",
                "party" => "Happy child at birthday party",
                "love" => "Couple walking in golden sunset",
                "sad" => "Child looking out rainy window",
                "adventure" => "Boy with backpack exploring forest",
                "dance" => "Girl spinning and dancing joyfully",
                "christmas" => "Children opening Christmas gifts",
                "animal" => "Child playing with cute puppy",
                "school" => "Children learning in colorful classroom",
                "nature" => "Child running through flower meadow",
                _ => "Happy child playing in sunny park"
            };

            string[] emotions = _detectedContext switch
            {
                "lullaby" => new[] { "sleepy", "peaceful", "calm", "dreamy", "gentle" },
                "party" => new[] { "excited", "joyful", "happy", "funny", "surprised" },
                "love" => new[] { "loving", "romantic", "happy", "nostalgic", "peaceful" },
                "sad" => new[] { "sad", "nostalgic", "calm", "peaceful", "hopeful" },
                "adventure" => new[] { "curious", "excited", "brave", "happy", "triumphant" },
                "dance" => new[] { "joyful", "excited", "playful", "happy", "energetic" },
                _ => new[] { "happy", "playful", "excited", "calm", "curious" }
            };

            string[] actions = _detectedContext switch
            {
                "lullaby" => new[] { "sleeping", "yawning", "snuggling", "dreaming", "resting" },
                "party" => new[] { "blowing candles", "opening gifts", "dancing", "laughing", "celebrating" },
                "love" => new[] { "walking together", "holding hands", "smiling", "hugging", "looking at sunset" },
                "sad" => new[] { "sitting quietly", "looking out window", "walking alone", "reflecting", "watching rain" },
                "adventure" => new[] { "exploring", "climbing", "running", "discovering", "hiking" },
                "dance" => new[] { "dancing", "spinning", "jumping", "moving", "swaying" },
                _ => new[] { "playing", "running", "dancing", "walking", "jumping" }
            };

            string[] locations = _detectedContext switch
            {
                "lullaby" => new[] { "cozy bedroom", "moonlit nursery", "starry night room", "soft lamp lit bedroom" },
                "party" => new[] { "birthday party room", "decorated garden", "festive hall", "colorful backyard" },
                "love" => new[] { "sunset beach", "flower garden", "park at golden hour", "romantic forest path" },
                "sad" => new[] { "rainy window", "empty park", "autumn forest", "grey cloudy day" },
                "adventure" => new[] { "forest clearing", "mountain path", "meadow", "hidden trail", "river bank" },
                "dance" => new[] { "dance floor", "sunny park", "colorful stage", "outdoor festival" },
                _ => new[] { "park", "garden", "playground", "sunny field" }
            };

            string[] keywordsList = _universalKeywords.ToArray();
            string[] ambientSounds = _detectedContext switch
            {
                "lullaby" => new[] { "soft lullaby music", "none", "gentle wind", "none", "soft music box" },
                "party" => new[] { "children laughing", "party noise", "children laughing", "joyful celebration sounds" },
                "sad" => new[] { "rain", "wind", "rain", "none", "distant birds" },
                "nature" => new[] { "birds", "leaves", "forest", "water", "wind" },
                "christmas" => new[] { "none", "fireplace", "children laughing", "none", "wind" },
                _ => new[] { "birds", "children laughing", "wind", "leaves", "playground" }
            };

            for (int i = 0; i < _lyricLines.Count; i++)
            {
                int energy = 3;
                if (_detectedContext == "lullaby")
                {
                    energy = 1;
                }
                else if (_detectedContext == "sad")
                {
                    energy = i < 2 ? 1 : 2;
                }
                else if (_detectedContext == "party" || _detectedContext == "dance")
                {
                    if (i < 1) energy = 2;
                    else if (i >= _lyricLines.Count - 1) energy = 2;
                    else energy = 4;
                }
                else
                {
                    if (i < 2) energy = 2;
                    else if (i > _lyricLines.Count - 3) energy = 2;
                    else if (i > 2 && i < _lyricLines.Count - 3) energy = 4;
                    if (_lyricLines.Count >= 10 && i == (int)(_lyricLines.Count * 0.7)) energy = 5;
                }

                scenes.Add(new StoryScene
                {
                    SceneNumber = i + 1,
                    Description = _lyricLines[i].Length > 50 ? _lyricLines[i].Substring(0, 47) + "..." : _lyricLines[i],
                    Emotion = emotions[i % emotions.Length],
                    Energy = energy,
                    Characters = mainCharacter,
                    Action = actions[i % actions.Length],
                    Location = locations[i % locations.Length],
                    Keywords = keywordsList[i % keywordsList.Length],
                    AmbientSound = ambientSounds[i % ambientSounds.Length]
                });
            }

            string overallTheme = _detectedContext switch
            {
                "lullaby" => "Peaceful bedtime",
                "party" => "Joyful celebration",
                "love" => "Romantic love story",
                "sad" => "Emotional journey",
                "adventure" => "Exciting adventure",
                "dance" => "Joyful dance",
                "christmas" => "Magical Christmas",
                "animal" => "Animal friends",
                "school" => "Learning adventure",
                "nature" => "Nature beauty",
                _ => _selectedTheme == "calm" ? "Peaceful adventure" :
                       _selectedTheme == "educational" ? "Learning adventure" :
                       _selectedTheme == "action" ? "Exciting adventure" : "Fun adventure"
            };

            return new StoryBoard
            {
                Scenes = scenes,
                MainCharacter = mainCharacter,
                OverallTheme = overallTheme
            };
        }

        #endregion

        #region Pixabay Music API (samo za muziku, NE za zvukove)

        private async Task<string> DownloadBackgroundMusic(string mood, double targetDuration, string tempDir, CancellationToken ct)
        {
            if (string.IsNullOrEmpty(_pixabayApiKey))
                return null;

            string searchQuery = _detectedContext switch
            {
                "lullaby" => "lullaby soft piano baby sleep",
                "party" => "happy upbeat birthday kids celebration",
                "love" => "romantic piano soft acoustic love",
                "sad" => "melancholy piano emotional soft",
                "adventure" => "adventure orchestral energetic exploration",
                "dance" => "upbeat dance kids fun energetic",
                "christmas" => "christmas joyful holiday bells warm",
                "animal" => "playful cute whimsical animals fun",
                "school" => "playful educational kids learning fun",
                "nature" => "nature acoustic peaceful gentle outdoor",
                _ => mood?.ToLower() switch
                {
                    "happy" or "joyful" => "happy children upbeat",
                    "calm" or "peaceful" => "calm relaxing piano",
                    "excited" or "energetic" => "upbeat energetic fun",
                    "playful" => "playful funny kids",
                    "melancholy" => "melancholy emotional soft piano",
                    "romantic" => "romantic acoustic soft piano",
                    _ => "children happy uplifting"
                }
            };

            for (int attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    await _apiRateLimiter.WaitAsync(ct);

                    try
                    {
                        string url = $"https://pixabay.com/api/music/?key={_pixabayApiKey}&q={Uri.EscapeDataString(searchQuery)}&duration=30-300";
                        string response = await _httpClient.GetStringAsync(url, ct);
                        var json = JObject.Parse(response);
                        var hits = json["hits"] as JArray;

                        if (hits == null || hits.Count == 0)
                        {
                            url = $"https://pixabay.com/api/music/?key={_pixabayApiKey}&q=happy%20kids&duration=30-300";
                            response = await _httpClient.GetStringAsync(url, ct);
                            json = JObject.Parse(response);
                            hits = json["hits"] as JArray;
                        }

                        if (hits != null && hits.Count > 0)
                        {
                            var rng = new Random(Guid.NewGuid().GetHashCode());
                            var hit = hits[rng.Next(Math.Min(5, hits.Count))];
                            string audioUrl = hit["audio"]?["url"]?.ToString();

                            if (!string.IsNullOrEmpty(audioUrl))
                            {
                                string fileName = $"background_{Guid.NewGuid().ToString().Substring(0, 8)}.mp3";
                                string outputPath = Path.Combine(tempDir, fileName);

                                LogToMainWindow($"🎵 Preuzimam pozadinsku muziku: {hit["title"]?.ToString() ?? searchQuery}");

                                byte[] data = await _httpClient.GetByteArrayAsync(audioUrl, ct);
                                await File.WriteAllBytesAsync(outputPath, data, ct);

                                double duration = hit["duration"]?.Value<double>() ?? 0;
                                if (duration < targetDuration && duration > 0)
                                {
                                    return await LoopAudio(outputPath, targetDuration, tempDir, ct);
                                }

                                return outputPath;
                            }
                        }
                    }
                    finally
                    {
                        _apiRateLimiter.Release();
                    }
                }
                catch (Exception ex)
                {
                    LogToMainWindow($"❌ Greška pri preuzimanju muzike: {ex.Message}");
                }
            }

            return null;
        }

        private async Task<string> LoopAudio(string audioPath, double targetDuration, string tempDir, CancellationToken ct)
        {
            string outputPath = Path.Combine(tempDir, $"looped_{Guid.NewGuid().ToString().Substring(0, 8)}.mp3");
            string ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Ffmpeg", "ffmpeg.exe");

            if (!File.Exists(ffmpegPath))
                return audioPath;

            string args = $"-stream_loop -1 -i \"{audioPath}\" -t {targetDuration.ToString(CultureInfo.InvariantCulture)} -c copy -y \"{outputPath}\"";
            var process = new Process
            {
                StartInfo = new ProcessStartInfo { FileName = ffmpegPath, Arguments = args, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true }
            };
            process.Start();
            await process.WaitForExitAsync();

            return File.Exists(outputPath) ? outputPath : audioPath;
        }

        private async Task<double> GetAudioDuration(string audioPath)
        {
            try
            {
                string ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Ffmpeg", "ffmpeg.exe");
                if (!File.Exists(ffmpegPath)) return 180.0;

                string args = $"-i \"{audioPath}\" -f null - 2>&1";
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo { FileName = ffmpegPath, Arguments = args, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true }
                };
                process.Start();
                string output = await process.StandardError.ReadToEndAsync();
                await process.WaitForExitAsync();

                var match = System.Text.RegularExpressions.Regex.Match(output, @"Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})");
                if (match.Success)
                {
                    int hours = int.Parse(match.Groups[1].Value);
                    int minutes = int.Parse(match.Groups[2].Value);
                    double seconds = double.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture);
                    return hours * 3600 + minutes * 60 + seconds;
                }
                return 180.0;
            }
            catch { return 180.0; }
        }

        #endregion

        #region Audio Processing (SAMO Freesound, NEMA PIXABAY)

        private async Task<string> GetAmbientSoundPath(string soundType, string tempDir, CancellationToken ct)
        {
            LogToMainWindow($"🔊 GetAmbientSoundPath: soundType='{soundType}', context='{_detectedContext}', AmbientSoundsEnabled={_enableAmbientSounds}");

            if (!_enableAmbientSounds || string.IsNullOrEmpty(soundType) || soundType == "none")
            {
                LogToMainWindow($"🔊 Ambijentalni zvukovi isključeni ili soundType prazan");
                return null;
            }

            // 1. Provjeri lokalne fajlove
            string localPath = await GetLocalAmbientSound(soundType, tempDir);
            if (localPath != null)
            {
                LogToMainWindow($"✅ Lokalni ambijentalni zvuk: {localPath}");
                return localPath;
            }

            // 2. SAMO Freesound - NEMA PIXABAY FALLBACKA!
            if (_freesound != null)
            {
                try
                {
                    string freesoundQuery = BuildFreesoundQuery(soundType, _detectedContext);
                    LogToMainWindow($"🔊 Freesound pretraga: '{freesoundQuery}'");
                    string freesoundPath = await _freesound.GetAmbientSound(freesoundQuery, tempDir);
                    if (!string.IsNullOrEmpty(freesoundPath))
                    {
                        LogToMainWindow($"✅ Freesound zvuk preuzet: {freesoundQuery}");
                        return freesoundPath;
                    }
                    else
                    {
                        LogToMainWindow($"⚠️ Freesound: nema rezultata za '{freesoundQuery}' — {_freesound.LastError ?? "nepoznata greška"}");
                    }
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    LogToMainWindow($"⚠️ Freesound greška: {ex.Message}");
                }
            }
            else
            {
                LogToMainWindow($"⚠️ Freesound nije inicijalizovan. Ambijentalni zvukovi nedostupni.");
            }

            LogToMainWindow($"⚠️ Nema ambijentalnog zvuka za '{soundType}'");
            return null;
        }

        /// <summary>
        /// Normalizuje slobodni AI tekst za ambient zvuk na naše definirane tipove.
        /// AI može vratiti "zvuk kućanstva" ili "zvuk pješčane staze" —
        /// ovo mapira te opise na Freesound-ready tipove.
        /// Ako ne može mapirati, poziva InferAmbientFromLyric kao fallback.
        /// </summary>
        private string NormalizeAmbientFromAI(string aiAmbient, string lyric, string context)
        {
            if (string.IsNullOrWhiteSpace(aiAmbient))
                return InferAmbientFromLyric(lyric, context);

            string lower = aiAmbient.ToLower();

            // Ako je već naš mapirani tip (iz InferAmbientFromLyric), vrati direktno
            var knownTypes = new[] {
                "birds chirping", "stream flowing", "ocean waves", "gentle rain",
                "park ambience", "children playing", "home warmth", "lullaby music box",
                "morning birds", "night crickets", "forest birds", "summer nature",
                "children playing snow", "footsteps gravel", "park outdoor birds",
                "fireplace crackling", "indoor quiet birds", "children laughing",
                "children snow playing", "park birds"
            };
            if (knownTypes.Any(k => lower.Contains(k.Split(' ')[0])))
                return aiAmbient;

            // Mapiraj slobodni AI tekst na naše tipove
            // Zvuci prirode / ptica
            if (lower.Contains("ptic") || lower.Contains("šume") || lower.Contains("prirode") ||
                lower.Contains("drveć") || lower.Contains("šuma") || lower.Contains("grana"))
                return InferAmbientFromLyric(lyric, context);

            // Park / šetnja
            if (lower.Contains("park") || lower.Contains("šetanj") || lower.Contains("staza") ||
                lower.Contains("pješčan") || lower.Contains("koraka") || lower.Contains("hodanj"))
                return "park ambience footsteps";

            // Djeca / igranje
            if (lower.Contains("djec") || lower.Contains("djet") || lower.Contains("igre") ||
                lower.Contains("kretanj") || lower.Contains("trčanj"))
                return "children playing outdoor";

            // Zima / snijeg
            if (lower.Contains("zim") || lower.Contains("snijeg") || lower.Contains("sneg") ||
                lower.Contains("hlad") || lower.Contains("mraz"))
                return "children playing snow";

            // Kućanstvo / unutra / restoran
            if (lower.Contains("kuć") || lower.Contains("restoran") || lower.Contains("unutra") ||
                lower.Contains("topli") || lower.Contains("dom") || lower.Contains("soba"))
                return "home warmth gentle";

            // Ljeto / sladoled / sunce
            if (lower.Contains("ljeto") || lower.Contains("leto") || lower.Contains("sunce") ||
                lower.Contains("toplo") || lower.Contains("sladoled"))
                return "summer park children";

            // Porodica / mama / tata
            if (lower.Contains("mama") || lower.Contains("tata") || lower.Contains("baka") ||
                lower.Contains("deka") || lower.Contains("porodic") || lower.Contains("zajedno"))
                return "park ambience family";

            // Fallback: pozovi InferAmbientFromLyric koji čita stih direktno
            return InferAmbientFromLyric(lyric, context);
        }

        private string BuildFreesoundQuery(string soundType, string context)
        {
            if (string.IsNullOrEmpty(soundType)) soundType = "nature";
            string lower = soundType.ToLower();

            // ══════════════════════════════════════════════════════════════
            // DIREKTNO MAPIRANJE — svaki soundType iz InferAmbientFromLyric
            // PRAVILO: Queriji moraju vraćati FIELD RECORDINGS, ne muziku.
            // Kratki, precizni queriji (2-3 rijeci) bolje rade na Freesondu.
            // Izbjegavati: "cozy", "gentle", "ambient" — vraćaju muziku.
            // Koristiti: konkretne zvukove — "birds", "crickets", "footsteps".
            // ══════════════════════════════════════════════════════════════

            // Ptice
            if (lower.Contains("birds chirping spring"))   return "birds chirping spring";
            if (lower.Contains("morning birds"))           return "birds morning chirping";
            if (lower.Contains("birds chirping"))          return "birds chirping";
            if (lower.Contains("birds outdoor"))           return "birds outdoor";
            if (lower.Contains("birds"))                   return "birds nature";

            // Voda / potok
            if (lower.Contains("stream flowing"))          return "stream water flowing";
            if (lower.Contains("forest stream"))           return "forest stream water";
            if (lower.Contains("ocean waves"))             return "ocean waves";
            if (lower.Contains("rain"))                    return "rain outdoor";
            if (lower.Contains("thunder"))                 return "thunder rain storm";
            if (lower.Contains("stream") || lower.Contains("water")) return "stream water";

            // Vjetar
            if (lower.Contains("gentle breeze"))           return "breeze wind leaves";
            if (lower.Contains("mountain wind"))           return "mountain wind outdoor";
            if (lower.Contains("winter wind"))             return "wind snow winter";
            if (lower.Contains("wind"))                    return "wind outdoor";

            // Djeca — konkretni zvuci, ne "party ambient"
            if (lower.Contains("children playing snow"))   return "children snow playing";
            if (lower.Contains("children laughing"))       return "children laughing outdoor";
            if (lower.Contains("children group"))          return "children outdoor group";
            if (lower.Contains("children birthday"))       return "children birthday singing";
            if (lower.Contains("children playground"))     return "children playground";
            if (lower.Contains("children playing"))        return "children playing outdoor";

            // Park / outdoor — konkretni zvuci
            if (lower.Contains("park ambience footsteps")) return "footsteps gravel park";
            if (lower.Contains("park ambience family"))    return "park outdoor birds";
            if (lower.Contains("park ambience birds"))     return "park birds";
            if (lower.Contains("park ambience"))           return "park birds outdoor";
            if (lower.Contains("summer park children"))    return "summer park outdoor";
            if (lower.Contains("city park"))               return "city park birds";

            // Šuma / priroda
            if (lower.Contains("forest birds nature"))     return "forest birds";
            if (lower.Contains("forest animals"))          return "forest animals";
            if (lower.Contains("forest"))                  return "forest nature";

            // Godišnja doba
            if (lower.Contains("summer nature crickets"))  return "summer crickets";
            if (lower.Contains("summer meadow"))           return "meadow insects summer";
            if (lower.Contains("autumn leaves"))           return "leaves rustling wind";

            // Dom / toplina — OPASNO: "cozy indoor" vraća muziku na Freesondu!
            // Koristimo konkretne zvukove umjesto opisa raspoloženja.
            if (lower.Contains("home warmth fireplace"))   return "fireplace crackling";
            if (lower.Contains("home warmth gentle"))      return "indoor quiet birds";
            if (lower.Contains("home warmth"))             return "fireplace wood crackling";

            // Noć / tišina — OPASNO: "night ambient" vraća muziku!
            if (lower.Contains("lullaby music box"))       return "music box";
            if (lower.Contains("lullaby"))                 return "music box gentle";
            if (lower.Contains("night crickets"))          return "crickets night";
            if (lower.Contains("morning birds"))           return "birds morning";

            // Životinje — konkretni zvuci
            if (lower.Contains("dog playing"))             return "dog outdoor";
            if (lower.Contains("cat purring"))             return "cat purring";
            if (lower.Contains("horse hooves"))            return "horse hooves";
            if (lower.Contains("forest animals"))          return "forest animals";
            if (lower.Contains("animals"))                 return "animals outdoor";

            // ══════════════════════════════════════════════════════════════
            // KONTEKST FALLBACK — uvijek sigurni zvuci koji NE vraćaju muziku
            // ══════════════════════════════════════════════════════════════
            if (context == "lullaby")    return "music box";
            if (context == "party")      return "children laughing";
            if (context == "sad")        return "rain outdoor";
            if (context == "adventure")  return "forest birds";
            if (context == "christmas")  return "fireplace crackling";
            if (context == "outdoor")    return "park birds";
            if (context == "health")     return "birds outdoor";
            if (context == "nature")     return "forest stream";

            return "birds outdoor";
        }

        private async Task<string> GetLocalAmbientSound(string soundType, string tempDir)
        {
            // ── Mapiranje soundType ključnih riječi → lokalni fajl u Assets/Sounds/ ──────
            // Redosljed je bitan: specifičniji matchevi dolaze PRIJE općih.
            // Svaki fajl se pokušava s .mp3, pa s .wav ekstenzijom.
            // Lokalni fajl = PRVI prioritet. Freesound = fallback samo ako lokalni ne postoji.
            var soundMap = new List<(string keyword, string file)>
            {
                // ── Ptice ────────────────────────────────────────────────────────────────
                ("birds chirping spring",   "birds-morning"),      // jutarnje ptice proljeće
                ("birds morning",           "birds-morning"),      // jutarnje ptice
                ("morning birds",           "birds-morning"),      // jutarnje ptice (obrnuti redosljed)
                ("birds forest",            "birds-forest"),       // šumske ptice
                ("forest birds",            "birds-forest"),       // šumske ptice
                ("birds chirping",          "birds-morning"),      // općenito cvrkut ptica
                ("birds outdoor",           "birds-morning"),      // ptice vani
                ("birds nature",            "birds-forest"),       // ptice priroda
                ("birds",                   "birds-morning"),      // generički fallback za ptice

                // ── Park / vanjski ambijent ───────────────────────────────────────────────
                ("park ambience",           "park-ambience"),      // park ambijent
                ("park birds",              "park-ambience"),      // ptice u parku
                ("park outdoor",            "park-ambience"),      // vanjski park
                ("outdoor",                 "park-ambience"),      // vanjski prostor

                // ── Djeca ────────────────────────────────────────────────────────────────
                ("children snow",           "children-snow"),      // djeca u snijegu
                ("children playing snow",   "children-snow"),      // djeca se igraju u snijegu
                ("children laughing",       "children-playing"),   // djeca se smiju
                ("children playing",        "children-playing"),   // djeca se igraju
                ("kids laughing",           "children-playing"),   // djeca (engleski)
                ("kids playing",            "children-playing"),   // djeca se igraju (engleski)
                ("playground",              "children-playing"),   // igralište
                ("children",               "children-playing"),   // generički fallback za djecu

                // ── Vatra / toplina ──────────────────────────────────────────────────────
                ("fireplace",              "fireplace"),           // kamin
                ("fire crackling",         "fireplace"),           // vatra puca
                ("home warmth",            "fireplace"),           // toplina doma
                ("indoor warmth",          "fireplace"),           // unutarnja toplina
                ("christmas",              "fireplace"),           // Božić → kamin

                // ── Voda / potok ──────────────────────────────────────────────────────────
                ("stream flowing",         "stream-water"),        // potok teče
                ("forest stream",          "stream-water"),        // šumski potok
                ("stream water",           "stream-water"),        // potok/voda
                ("water stream",           "stream-water"),        // voda potok
                ("stream",                 "stream-water"),        // generički potok
                ("water",                  "stream-water"),        // voda

                // ── Kiša ──────────────────────────────────────────────────────────────────
                ("gentle rain",            "gentle-rain"),         // blaga kiša
                ("soft rain",              "gentle-rain"),         // tiha kiša
                ("rain outdoor",           "gentle-rain"),         // kiša vani
                ("rain",                   "gentle-rain"),         // kiša generički
                ("sad",                    "gentle-rain"),         // tužna scena → kiša

                // ── Ljetni zvukovi ────────────────────────────────────────────────────────
                ("summer nature crickets", "summer-crickets"),     // ljetni cvrčci
                ("night crickets",         "summer-crickets"),     // noćni cvrčci
                ("summer crickets",        "summer-crickets"),     // ljetni cvrčci
                ("crickets",               "summer-crickets"),     // cvrčci generički
                ("summer nature",          "summer-crickets"),     // ljetna priroda

                // ── Koraci ────────────────────────────────────────────────────────────────
                ("footsteps gravel",       "footsteps-gravel"),    // koraci na šljunku
                ("gravel footsteps",       "footsteps-gravel"),    // koraci na šljunku
                ("footsteps",              "footsteps-gravel"),    // koraci generički

                // ── Šuma / priroda generički ──────────────────────────────────────────────
                ("forest ambience",        "birds-forest"),        // šumski ambijent
                ("forest",                 "birds-forest"),        // šuma generički
                ("nature",                 "birds-forest"),        // priroda generički
                ("mountain",               "birds-forest"),        // planina → šuma/ptice

                // ── Lullaby / uspavanke ───────────────────────────────────────────────────
                ("lullaby",                "gentle-rain"),         // uspavanke → tiha kiša
                ("sleep",                  "gentle-rain"),         // spavanje → tiha kiša
                ("night",                  "summer-crickets"),     // noć → cvrčci
            };

            string lower = soundType?.ToLower() ?? string.Empty;
            string soundsDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Sounds");

            foreach (var (keyword, file) in soundMap)
            {
                if (!lower.Contains(keyword)) continue;

                // Pokušaj .mp3 pa .wav
                foreach (string ext in new[] { ".mp3", ".wav", ".flac", ".ogg" })
                {
                    string sourcePath = Path.Combine(soundsDir, file + ext);
                    if (File.Exists(sourcePath))
                    {
                        string outputPath = Path.Combine(tempDir, $"ambient_{Guid.NewGuid().ToString().Substring(0, 8)}{ext}");
                        await Task.Run(() => File.Copy(sourcePath, outputPath, true));
                        LogToMainWindow($"🔊 Lokalni zvuk: '{file}{ext}' za '{soundType}'");
                        return outputPath;
                    }
                }
            }

            // Nijedan lokalni fajl nije pronađen → Freesound fallback
            LogToMainWindow($"🔊 Nema lokalnog zvuka za '{soundType}', koristim Freesound fallback");
            return null;
        }

        private async Task<string> MixAmbientWithMusic(string musicPath, List<StoryScene> scenes, double totalDuration, string tempDir)
        {
            if (!_enableAmbientSounds || scenes.All(s => string.IsNullOrEmpty(s.AmbientPath)))
            {
                LogToMainWindow("🔊 Ambijentalni zvukovi isključeni ili nema zvukova za miksanje");
                return musicPath;
            }

            string ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Ffmpeg", "ffmpeg.exe");
            if (!File.Exists(ffmpegPath)) return musicPath;

            double ambientVolume = _detectedContext switch
            {
                "lullaby" => 0.08,
                "sad" => 0.10,
                "party" => 0.20,
                "dance" => 0.20,
                "adventure" => 0.18,
                "christmas" => 0.16,
                "love" => 0.12,
                "nature" => 0.14,
                _ => 0.15
            };

            LogToMainWindow($"🔊 Miksiram ambijentalne zvukove sa muzikom ({scenes.Count(s => !string.IsNullOrEmpty(s.AmbientPath))} zvukova, volumen={ambientVolume:F2})");

            var filterParts = new List<string>();
            var inputs = new List<string>();

            inputs.Add($"-i \"{musicPath}\"");
            filterParts.Add($"[0:a]volume=1.0[a0]");

            int ambientIndex = 1;
            for (int i = 0; i < scenes.Count; i++)
            {
                if (!string.IsNullOrEmpty(scenes[i].AmbientPath) && File.Exists(scenes[i].AmbientPath))
                {
                    inputs.Add($"-i \"{scenes[i].AmbientPath}\"");
                    double startTime = scenes[i].StartTime;
                    double duration  = scenes[i].Duration;
                    string startMs   = ((long)(startTime * 1000)).ToString();
                    double endTime   = startTime + duration;

                    // ISPRAVAN REDOSLED:
                    // 1. aloop — loopuj kratki zvuk da popuni cijelu scenu
                    // 2. adelay — pomjeri na tačnu poziciju u timeline-u
                    // 3. atrim=end — odsijeci na kraj scene (apsolutno vrijeme)
                    // 4. volume — primijeni glasnoću
                    filterParts.Add(
                        $"[{ambientIndex}:a]" +
                        $"aloop=loop=-1:size=2e+09," +
                        $"adelay={startMs}|{startMs}," +
                        $"atrim=end={endTime.ToString("F3", CultureInfo.InvariantCulture)}," +
                        $"volume={ambientVolume.ToString("F2", CultureInfo.InvariantCulture)}" +
                        $"[a{ambientIndex}]");
                    ambientIndex++;
                    LogToMainWindow($"🔊 Dodajem zvuk za scenu {i + 1}: start={startTime:F1}s, duration={duration:F1}s");
                }
            }

            if (ambientIndex == 1) return musicPath;

            string allInputs = string.Join(" ", inputs);
            string filterGraph = string.Join(";", filterParts);

            var mixInputs = new List<string>();
            mixInputs.Add("[a0]");
            for (int i = 1; i < ambientIndex; i++)
                mixInputs.Add($"[a{i}]");

            string mixFilter = string.Join("", mixInputs);
            string outputPath = Path.Combine(tempDir, $"mixed_audio_{Guid.NewGuid().ToString().Substring(0, 8)}.mp3");

            // normalize=0 je KRITIČNO — bez toga amix dijeli svaki input s brojem inputa
            // (20 inputa = svaki na 5% volumena, muzika postaje nečujna)
            string args = $"-nostdin {allInputs} -filter_complex \"{filterGraph};{mixFilter}amix=inputs={mixInputs.Count}:duration=first:normalize=0\" -t {totalDuration.ToString(CultureInfo.InvariantCulture)} -y \"{outputPath}\"";

            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = ffmpegPath,
                    Arguments = args,
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardError = true,
                    RedirectStandardOutput = true
                }
            };

            process.Start();
            // OBAVEZNO - bez ovoga FFmpeg deadlockuje na 90% kada stderr buffer postane pun
            process.BeginErrorReadLine();
            process.BeginOutputReadLine();

            // Timeout 120s - ako ne završi, odustajemo (ne visi zauvijek)
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(120));
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                LogToMainWindow("⚠️ Miksanje zvuka prekoračilo timeout (120s) - koristim originalnu muziku");
                try { process.Kill(); } catch { }
                return musicPath;
            }

            if (File.Exists(outputPath) && new FileInfo(outputPath).Length > 0)
            {
                LogToMainWindow($"✅ Ambijentalni zvukovi uspješno miksnani");
                return outputPath;
            }

            return musicPath;
        }

        #endregion

        #region Transition Sounds

        private async Task<string> GetTransitionSound(string tempDir, string type = "pop")
        {
            if (!_enableTransitionSounds) return null;

            // Ako već imamo taj tip u kešu, samo kopiraj
            if (_transitionSoundCache.TryGetValue(type, out string cachedSource) && File.Exists(cachedSource))
            {
                string copyPath = Path.Combine(tempDir, $"transition_{type}_{Guid.NewGuid().ToString().Substring(0, 8)}.mp3");
                File.Copy(cachedSource, copyPath, true);
                return copyPath;
            }

            // Pokušaj lokalni fajl prvo (Assets/Sounds/)
            string soundFile = type == "pop" ? "transition-pop.mp3" : "transition-whoosh.mp3";
            string localPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Sounds", soundFile);
            if (File.Exists(localPath))
            {
                string outputPath = Path.Combine(tempDir, $"transition_{type}_{Guid.NewGuid().ToString().Substring(0, 8)}.mp3");
                File.Copy(localPath, outputPath, true);
                _transitionSoundCache[type] = outputPath;
                return outputPath;
            }

            // Generiši zvuk programski pomoću NAudio — bez FFmpeg, bez interneta
            // Rezultat: profesionalan UI zvuk s pravim ADSR envelope-om
            try
            {
                string genPath = Path.Combine(tempDir, $"transition_{type}_{Guid.NewGuid().ToString().Substring(0, 8)}.wav");
                bool ok = type == "pop"
                    ? GeneratePopSound(genPath)
                    : GenerateWhooshSound(genPath);

                if (ok && File.Exists(genPath))
                {
                    _transitionSoundCache[type] = genPath;
                    LogToMainWindow($"🔊 Tranzicioni zvuk generisan: {type}");
                    string copyPath = Path.Combine(tempDir, $"transition_{type}_{Guid.NewGuid().ToString().Substring(0, 8)}.wav");
                    File.Copy(genPath, copyPath, true);
                    return copyPath;
                }
            }
            catch (Exception ex)
            {
                LogToMainWindow($"⚠️ Greška pri generisanju zvuka: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Generiše suptilan UI "pop" zvuk pomoću NAudio.
        /// Zvuk: kratki niskofrekventni klik s mekim ADSR envelope-om.
        /// Namijenjen da bude jedva čujan ispod muzike — kao elegantna tranzicija.
        /// </summary>
        private bool GeneratePopSound(string outputPath)
        {
            const int sampleRate = 44100;
            const int channels = 2;
            // Ukupno trajanje: 180ms — dovoljno kratko da ne ometa muziku
            double totalSeconds = 0.18;
            int totalSamples = (int)(sampleRate * totalSeconds);

            var samples = new float[totalSamples * channels];
            var rng = new Random(42);

            for (int i = 0; i < totalSamples; i++)
            {
                double t = (double)i / sampleRate;
                double tNorm = t / totalSeconds; // 0..1

                // Envelope: brzi attack (0-5ms), eksponencijalni decay (5-180ms)
                // Rezultat: kratki klik koji se odmah gasi, ne "bip" koji zvoni
                double envelope;
                if (t < 0.005)
                    envelope = t / 0.005; // Attack: 0→1 za 5ms
                else
                    envelope = Math.Exp(-18.0 * (t - 0.005)); // Decay: eksponencijalni pad

                // Zvuk: niskofrekventni bump (80Hz osnova) + kratki šum za "klik" teksturu
                // 80Hz daje "mekoću", šum daje "realnost" zvuka
                double fundamental = Math.Sin(2 * Math.PI * 80 * t) * 0.6;
                double harmonic    = Math.Sin(2 * Math.PI * 160 * t) * 0.25;
                double click       = (rng.NextDouble() * 2 - 1) * Math.Exp(-120 * t) * 0.3;

                // Ukupan signal s envelope-om, skaliran na tiho (0.15 amplitude)
                // Tiho je namjerno — pop treba biti suptilan, ne agresivan
                double signal = (fundamental + harmonic + click) * envelope * 0.15;

                float sample = (float)Math.Clamp(signal, -1.0, 1.0);
                samples[i * channels]     = sample; // L
                samples[i * channels + 1] = sample; // R
            }

            return WriteWav(outputPath, samples, sampleRate, channels);
        }

        /// <summary>
        /// Generiše suptilan "whoosh" zvuk (šuštanje zraka) pomoću NAudio.
        /// Zvuk: filtrirani bijeli šum s fade-in/fade-out, 450ms.
        /// </summary>
        private bool GenerateWhooshSound(string outputPath)
        {
            const int sampleRate = 44100;
            const int channels = 2;
            double totalSeconds = 0.45;
            int totalSamples = (int)(sampleRate * totalSeconds);

            var samples = new float[totalSamples * channels];
            var rng = new Random(42);

            // Jednostavan IIR lowpass filter za "šuštanje" (ne oštar šum)
            double filterState = 0;
            const double filterCoeff = 0.12; // Propušta ~500Hz i ispod

            for (int i = 0; i < totalSamples; i++)
            {
                double t = (double)i / sampleRate;
                double tNorm = t / totalSeconds;

                // Envelope: blagi fade-in (0-80ms), pik na 40%, blagi fade-out (60-100%)
                double envelope;
                if (tNorm < 0.18)
                    envelope = tNorm / 0.18;
                else if (tNorm < 0.60)
                    envelope = 1.0;
                else
                    envelope = 1.0 - (tNorm - 0.60) / 0.40;

                // Filtrirani bijeli šum → mekši whoosh
                double noise = rng.NextDouble() * 2 - 1;
                filterState = filterState * (1 - filterCoeff) + noise * filterCoeff;

                // Suptilno: 0.12 amplitude — jedva čujno ispod muzike
                double signal = filterState * envelope * 0.12;

                float sample = (float)Math.Clamp(signal, -1.0, 1.0);
                samples[i * channels]     = sample;
                samples[i * channels + 1] = sample;
            }

            return WriteWav(outputPath, samples, sampleRate, channels);
        }

        /// <summary>Piše float[] samples u WAV fajl bez eksternih zavisnosti.</summary>
        private bool WriteWav(string path, float[] samples, int sampleRate, int channels)
        {
            try
            {
                using var writer = new NAudio.Wave.WaveFileWriter(
                    path,
                    NAudio.Wave.WaveFormat.CreateIeeeFloatWaveFormat(sampleRate, channels));
                writer.WriteSamples(samples, 0, samples.Length);
                return true;
            }
            catch (Exception ex)
            {
                LogToMainWindow($"⚠️ WriteWav greška: {ex.Message}");
                return false;
            }
        }

        #endregion

        #region Video Processing sa B-roll za instrumentalne dijelove

        private async Task ProcessVideoCreation(string audioPath, double totalDuration)
        {
            btnGenerate.Content = "🎬 AI kreira priču...";
            AnnounceToUser("AI analizira pjesmu i kreira priču...", 5);

            var storyBoard = await GenerateStoryBoard(_lyricLines, _cts?.Token ?? CancellationToken.None);

            if (storyBoard?.Scenes == null || storyBoard.Scenes.Count == 0)
            {
                LogToMainWindow("❌ Story board nije generisan, koristim fallback");
                storyBoard = CreateFallbackStoryBoard();
            }

            LogToMainWindow($"📖 Priča kreirana: {storyBoard.Scenes.Count} scena");
            LogToMainWindow($"👤 Glavni lik: {storyBoard.MainCharacter}");
            LogToMainWindow($"🎬 Tema: {storyBoard.OverallTheme}");

            _tempVideoFolder = Path.Combine(Path.GetTempPath(), $"UVE_Story_{Guid.NewGuid()}");
            Directory.CreateDirectory(_tempVideoFolder);

            _segments = new List<TimelineSegment>();

            // ========== LOGIKA ZA INSTRUMENTALNE DIJELOVE (B-roll) ==========
            // Detektuje praznine između stihova (uvod, bridge, outro)
            // i popunjava ih B-roll materijalom prilagođenim kontekstu pjesme

            // FIX: Duration na scenama nije još postavljen ovdje!
            // Izračunaj lyricsTotalDuration iz broja stihova × prosječno trajanje
            // Stihovi zauzimaju % ukupnog trajanja prema broju stihova
            int sceneCount = storyBoard.Scenes.Count;
            // Procjeni koliko traje dio sa stihovima (ostatak je instrumental)
            // Ako nema stihova, cijela pjesma je instrumentalna
            double estimatedSegDur = sceneCount > 0
                ? Math.Round(totalDuration / sceneCount, 2)
                : 0;
            double lyricsTotalDuration = sceneCount > 0
                ? Math.Round(estimatedSegDur * sceneCount, 2)
                : 0;
            // Ako stihovi pokrivaju skoro cijelu pjesmu, nema instrumentalnog dijela
            double remainingDuration = totalDuration - lyricsTotalDuration;
            double originalTotalDuration = totalDuration;

            // Instrumentalni dio postoji samo ako je značajan (>5% trajanja)
            if (remainingDuration > totalDuration * 0.05 && remainingDuration > 2.0)
            {
                LogToMainWindow($"🎵 Detektovan instrumentalni dio: {FormatTime(remainingDuration)} (ukupno trajanje: {FormatTime(totalDuration)}, stihovi: {FormatTime(lyricsTotalDuration)})");

                // B-roll keywords za instrumentalne dijelove, prilagođeni kontekstu pjesme
                List<string> bRollKeywords = new List<string>();

                switch (_detectedContext)
                {
                    case "lullaby":
                        bRollKeywords.AddRange(new[] {
                            "peaceful sleeping baby soft light cozy bedroom",
                            "moonlight night stars quiet gentle atmosphere",
                            "soft clouds floating gentle time lapse sky",
                            "slow motion nature peaceful waterfall calm",
                            "baby crib mobile turning soft light",
                            "mother kissing baby forehead goodnight warm",
                            "starry night sky twinkling stars peaceful"
                        });
                        break;
                    case "party":
                        bRollKeywords.AddRange(new[] {
                            "colorful abstract shapes celebration joyful background",
                            "happy kids dancing colorful clothes energetic",
                            "confetti colorful festive celebration falling",
                            "celebration lights bokeh happy joyful",
                            "birthday cake candles children excited cheering",
                            "balloons floating up colorful celebration",
                            "children jumping happy celebration fun"
                        });
                        break;
                    case "sad":
                        bRollKeywords.AddRange(new[] {
                            "rain on window melancholy quiet indoor",
                            "autumn leaves falling slow motion lonely",
                            "empty park bench cloudy day grey",
                            "gentle water ripples calm peaceful reflective",
                            "person sitting alone window thinking",
                            "foggy morning misty forest quiet",
                            "candle flickering alone dark room"
                        });
                        break;
                    case "adventure":
                        bRollKeywords.AddRange(new[] {
                            "children exploring forest adventure excited",
                            "nature landscape cinematic mountains sunrise",
                            "adventure travel scenic journey hiking",
                            "mountains clouds time lapse dramatic",
                            "kids running through field grass happy",
                            "forest path sunlight dappled exploring",
                            "river crossing bridge adventure outdoors"
                        });
                        break;
                    case "dance":
                        bRollKeywords.AddRange(new[] {
                            "colorful abstract dance background movement",
                            "children moving joyful silhouette dancing",
                            "party lights animation colorful rhythm",
                            "happy kids dancing background energetic",
                            "dance floor colorful lights movement",
                            "spinning colorful skirts dancing joyful",
                            "children group dance happy celebration"
                        });
                        break;
                    case "christmas":
                        bRollKeywords.AddRange(new[] {
                            "christmas lights cozy background warm",
                            "snow falling slow motion winter wonderland",
                            "fireplace crackling warm glow cozy indoor",
                            "holiday decorations magical sparkle",
                            "children opening christmas gifts excited happy",
                            "snowflakes gently falling winter landscape",
                            "christmas tree ornaments twinkling lights"
                        });
                        break;
                    case "nature":
                        bRollKeywords.AddRange(new[] {
                            "nature landscape cinematic beautiful mountains",
                            "flowers blooming time lapse colorful garden",
                            "sunset clouds peaceful orange sky",
                            "forest river flowing gentle water nature",
                            "butterflies flying flowers meadow spring",
                            "waterfall cascade nature peaceful green",
                            "meadow flowers wind gentle breeze"
                        });
                        break;
                    case "outdoor":
                    case "health":
                        bRollKeywords.AddRange(new[] {
                            "children walking park path sunny morning cinematic",
                            "birds singing trees nature spring peaceful bokeh",
                            "stream flowing forest nature gentle peaceful",
                            "family walking together park golden hour warm",
                            "child running grass meadow joyful slow motion",
                            "flowers blooming spring garden colorful nature",
                            "sunrise morning park mist golden light cinematic",
                            "park bench children playing background sunny day",
                            "autumn leaves park path children walking colorful",
                            "winter children snow playing cozy warm colors",
                        });
                        break;
                    case "seasons":
                        bRollKeywords.AddRange(new[] {
                            "spring flowers blooming children garden colorful",
                            "summer beach children playing sunshine warm",
                            "autumn leaves falling park path golden colors",
                            "winter snow children playing cozy warm bokeh",
                            "rain puddles children boots splashing happy",
                            "sunset children silhouette park golden hour",
                            "morning dew nature close-up cinematic beautiful",
                            "rainbow sky colorful nature children wonder",
                        });
                        break;
                    default: // fun / general
                        bRollKeywords.AddRange(new[] {
                            "children playing park nature sunny day cinematic",
                            "birds chirping morning trees nature peaceful",
                            "stream brook water nature sounds peaceful outdoor",
                            "children laughing running park sunny slow motion",
                            "nature landscape beautiful trees sky cinematic",
                            "flowers garden colorful spring bokeh nature",
                            "family outdoor together park warm golden light",
                            "child wonder exploring nature curiosity bokeh",
                        });
                        break;
                }

                // Izračunaj koliko B-roll kadrova treba (svaki ~3-5 sekundi)
                double bRollDurationPerClip = 4.0;
                int bRollCount = Math.Max(1, (int)Math.Ceiling(remainingDuration / bRollDurationPerClip));
                double actualDurationPerClip = remainingDuration / bRollCount;

                LogToMainWindow($"🎬 Kreiranje {bRollCount} B-roll kadrova za instrumentalni dio (po {actualDurationPerClip:F1}s)");

                // B-roll za UVOD (prije prve scene) - do 40% instrumentalnog dijela, max 10 sekundi
                double introPortion = Math.Min(remainingDuration * 0.4, 10.0);
                int introClips = Math.Max(1, (int)Math.Ceiling(introPortion / actualDurationPerClip));
                double introClipDuration = introPortion / introClips;

                double bRollStartTime = 0;

                for (int i = 0; i < introClips; i++)
                {
                    string keywords = bRollKeywords[i % bRollKeywords.Count];
                    string enhancedBroll = $"{keywords} {_detectedContext switch { "lullaby" => "soft light peaceful calm", "party" => "colorful joyful energetic", "sad" => "gentle melancholy quiet", "adventure" => "exciting dynamic outdoor", "dance" => "rhythmic colorful movement", "christmas" => "warm cozy magical", "nature" => "peaceful natural soft", _ => "warm colors happy cheerful" }}";

                    _segments.Insert(0, new TimelineSegment
                    {
                        Path = "",
                        Duration = introClipDuration,
                        StartTime = bRollStartTime,
                        Description = i == 0 ? "🎵 Uvod - instrumental" : "🎵 Uvod - nastavak",
                        LyricText = "",
                        AmbientSoundPath = null,
                        Energy = 2,
                        Emotion = _detectedContext == "lullaby" ? "calm" : "happy"
                    });

                    bRollStartTime += introClipDuration;
                    LogToMainWindow($"   B-roll uvod {i + 1}: {introClipDuration:F1}s - '{keywords}'");
                }

                // Pomjeri sve postojeće scene za trajanje uvoda
                double shift = introPortion;
                foreach (var scene in storyBoard.Scenes)
                {
                    scene.StartTime += shift;
                }

                // B-roll za OUTRO (poslije zadnje scene) - ostatak instrumentalnog dijela
                double outroPortion = remainingDuration - introPortion;
                if (outroPortion > 0.5)
                {
                    int outroClips = Math.Max(1, (int)Math.Ceiling(outroPortion / actualDurationPerClip));
                    double outroClipDuration = outroPortion / outroClips;
                    double outroStartTime = lyricsTotalDuration + introPortion;

                    for (int i = 0; i < outroClips; i++)
                    {
                        string keywords = bRollKeywords[(introClips + i) % bRollKeywords.Count];
                        string enhancedBroll = $"{keywords} {_detectedContext switch { "lullaby" => "soft light peaceful calm ending", "party" => "colorful joyful fading out", "sad" => "gentle melancholy quiet fade", "adventure" => "exciting dynamic conclusion", "dance" => "rhythmic colorful fade", "christmas" => "warm cozy magical ending", "nature" => "peaceful natural soft conclusion", _ => "warm colors happy cheerful ending" }}";

                        _segments.Add(new TimelineSegment
                        {
                            Path = "",
                            Duration = outroClipDuration,
                            StartTime = outroStartTime + (i * outroClipDuration),
                            Description = i == outroClips - 1 ? "🎵 Outro - kraj" : "🎵 Outro - instrumental",
                            LyricText = "",
                            AmbientSoundPath = null,
                            Energy = 2,
                            Emotion = _detectedContext == "lullaby" ? "calm" : "happy"
                        });

                        LogToMainWindow($"   B-roll outro {i + 1}: {outroClipDuration:F1}s - '{keywords}'");
                    }
                }

                // Resetuj ukupno trajanje za prikaz
                totalDuration = introPortion + lyricsTotalDuration + outroPortion;
                LogToMainWindow($"📊 Nakon dodavanja B-roll: uvod={introPortion:F1}s, stihovi={lyricsTotalDuration:F1}s, outro={outroPortion:F1}s, UKUPNO={totalDuration:F1}s");
            }
            // ========== KRAJ B-roll LOGIKE ==========

            try
            {
                string mediaType = (cmbMediaType.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "video";
                int count = storyBoard.Scenes.Count;
                double segDuration = totalDuration / Math.Max(1, count);

                for (int i = 0; i < count; i++)
                {
                    _cts?.Token.ThrowIfCancellationRequested();
                    var scene = storyBoard.Scenes[i];

                    if (i == count - 1)
                        scene.Duration = Math.Round(totalDuration - (i * segDuration), 2) + 1.0;
                    else
                        scene.Duration = Math.Round(i * segDuration + segDuration, 2) - Math.Round(i * segDuration, 2);

                    scene.StartTime = Math.Round(i * segDuration, 2);

                    string styleConsistency = _detectedContext switch
                    {
                        "lullaby" => "soft light cozy warm peaceful night",
                        "party" => "colorful bright happy festive vibrant",
                        "love" => "warm golden romantic soft glow",
                        "sad" => "grey moody soft desaturated melancholy",
                        "adventure" => "outdoor bright natural energetic",
                        "dance" => "colorful joyful movement bright",
                        "christmas" => "warm holiday lights cozy festive",
                        "animal" => "cute nature soft light warm",
                        "school" => "bright colorful educational warm",
                        "nature" => "natural sunlight green peaceful",
                        _ => "warm colors soft light happy atmosphere child friendly"
                    };
                    string energyBoost = scene.Energy >= 4 ? " action fast dynamic exciting" : scene.Energy <= 2 ? " calm peaceful slow gentle" : "";
                    string emotionBoost = scene.Emotion;

                    string enhancedKeywords = $"{scene.Keywords} {scene.Action} {emotionBoost}{energyBoost} {styleConsistency}";

                    LogToMainWindow($"🎬 Scena {i + 1}: Energy={scene.Energy}, Emotion={scene.Emotion}, Action={scene.Action}, Duration={scene.Duration:F1}s");

                    AnnounceToUser($"Scena {i + 1}/{count}: {scene.Description}...", 10 + (i * 70 / count));

                    string mediaPath = await SearchAndDownloadMedia(enhancedKeywords, 1080, mediaType, _cts?.Token ?? CancellationToken.None);

                    if (string.IsNullOrEmpty(mediaPath))
                        mediaPath = await SearchAndDownloadMedia(scene.Keywords, 1080, mediaType, _cts?.Token ?? CancellationToken.None);

                    if (string.IsNullOrEmpty(mediaPath))
                    {
                        var rng = new Random(i);
                        string fallback = _universalKeywords[rng.Next(_universalKeywords.Count)];
                        mediaPath = await SearchAndDownloadMedia(fallback, 1080, mediaType, _cts?.Token ?? CancellationToken.None);
                    }

                    if (!string.IsNullOrEmpty(mediaPath))
                    {
                        string finalPath = mediaPath;
                        if (mediaType == "video")
                        {
                            double videoDuration = await GetVideoDuration(mediaPath);
                            LogToMainWindow($"📹 Video trajanje: {videoDuration:F1}s, potrebno: {scene.Duration:F1}s");

                            if (Math.Abs(videoDuration - scene.Duration) > 0.5)
                                finalPath = await TrimVideoToDuration(mediaPath, scene.Duration, _tempVideoFolder);
                        }

                        // Ambijentalni zvukovi - SAMO Freesound (Pixabay uklonjen)
                        string ambientPath = await GetAmbientSoundPath(scene.AmbientSound, _tempVideoFolder, _cts?.Token ?? CancellationToken.None);
                        if (ambientPath != null)
                        {
                            scene.AmbientPath = ambientPath;
                            LogToMainWindow($"🔊 Ambijentalni zvuk za scenu {i + 1}: {scene.AmbientSound}");
                        }

                        _segments.Add(new TimelineSegment
                        {
                            Path = finalPath,
                            Duration = scene.Duration,
                            StartTime = scene.StartTime,
                            Description = scene.Description,
                            LyricText = _showLyrics ? _lyricLines[i] : "",
                            AmbientSoundPath = ambientPath,
                            Energy = scene.Energy,
                            Emotion = scene.Emotion
                        });
                        LogToMainWindow($"✅ Scena {i + 1}: medij preuzet");
                    }
                    else
                    {
                        LogToMainWindow($"❌ Scena {i + 1}: nema medija - preskačem!");
                    }

                    await Task.Delay(300, _cts?.Token ?? CancellationToken.None);
                }

                if (_segments.Any(s => !string.IsNullOrEmpty(s.AmbientSoundPath)) && _enableAmbientSounds)
                {
                    AnnounceToUser("Miksiram ambijentalne zvukove sa muzikom...", 90);

                    for (int idx = 0; idx < storyBoard.Scenes.Count && idx < _segments.Count; idx++)
                    {
                        if (!string.IsNullOrEmpty(_segments[idx].AmbientSoundPath))
                            storyBoard.Scenes[idx].AmbientPath = _segments[idx].AmbientSoundPath;
                    }

                    _ambientAudioPath = await MixAmbientWithMusic(audioPath, storyBoard.Scenes, totalDuration, _tempVideoFolder);
                }

                await CreateVideo(storyBoard);
            }
            catch (Exception ex) { WpfMessageBox.Show($"Greška: {ex.Message}", "Greška", MessageBoxButton.OK, MessageBoxImage.Error); }
            finally { btnGenerate.IsEnabled = true; btnGenerate.Content = "🎬 KREIRAJ VIDEO"; }
        }

        #endregion

        #region TrimVideoToDuration

        private async Task<string> TrimVideoToDuration(string inputPath, double targetDuration, string tempDir)
        {
            var sw = Stopwatch.StartNew();
            LogToMainWindow($"✂️ Trimovanje: {Path.GetFileName(inputPath)} sa {targetDuration:F1}s");

            try
            {
                string outputPath = Path.Combine(tempDir, $"trimmed_{Guid.NewGuid().ToString().Substring(0, 8)}.mp4");
                string ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Ffmpeg", "ffmpeg.exe");
                if (!File.Exists(ffmpegPath)) return inputPath;

                string args = $"-ss 0 -i \"{inputPath}\" -t {targetDuration.ToString(CultureInfo.InvariantCulture)} -c copy -avoid_negative_ts make_zero -y \"{outputPath}\"";
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo { FileName = ffmpegPath, Arguments = args, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true }
                };
                process.Start();
                await process.WaitForExitAsync();

                if (process.ExitCode == 0 && File.Exists(outputPath) && new FileInfo(outputPath).Length > 0)
                {
                    LogToMainWindow($"✅ Brzi trim uspješan za {sw.ElapsedMilliseconds}ms");
                    return outputPath;
                }

                LogToMainWindow($"⚠️ Brzi trim neuspješan, pokušavam re-encode...");
                string argsSlow = $"-ss 0 -i \"{inputPath}\" -t {targetDuration.ToString(CultureInfo.InvariantCulture)} -c:v libx264 -c:a aac -preset ultrafast -crf 23 -y \"{outputPath}\"";
                process = new Process
                {
                    StartInfo = new ProcessStartInfo { FileName = ffmpegPath, Arguments = argsSlow, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true }
                };
                process.Start();
                await process.WaitForExitAsync();

                if (process.ExitCode == 0 && File.Exists(outputPath))
                {
                    LogToMainWindow($"✅ Re-encode trim uspješan za {sw.ElapsedMilliseconds}ms");
                    return outputPath;
                }

                return inputPath;
            }
            catch (Exception ex)
            {
                LogToMainWindow($"❌ Trim greška: {ex.Message}");
                return inputPath;
            }
        }

        #endregion

        private async Task<double> GetVideoDuration(string videoPath)
        {
            try
            {
                string ffmpegPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Ffmpeg", "ffmpeg.exe");
                if (!File.Exists(ffmpegPath)) return 5.0;

                string args = $"-i \"{videoPath}\" -f null - 2>&1";
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo { FileName = ffmpegPath, Arguments = args, CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true }
                };
                process.Start();
                string output = await process.StandardError.ReadToEndAsync();
                await process.WaitForExitAsync();

                var match = System.Text.RegularExpressions.Regex.Match(output, @"Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})");
                if (match.Success)
                {
                    int hours = int.Parse(match.Groups[1].Value);
                    int minutes = int.Parse(match.Groups[2].Value);
                    double seconds = double.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture);
                    return hours * 3600 + minutes * 60 + seconds;
                }
                return 5.0;
            }
            catch { return 5.0; }
        }

        private async Task<string> SearchAndDownloadMedia(string keywords, int minWidth, string mediaType, CancellationToken ct)
        {
            LogToMainWindow($"🔍 SearchAndDownloadMedia: '{keywords.Substring(0, Math.Min(60, keywords.Length))}...', type={mediaType}");

            string apiKey = null;
            try
            {
                string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UltraVideoEditor");
                string keyFile = Path.Combine(settingsPath, "pixabay_key.bin");

                if (File.Exists(keyFile))
                {
                    byte[] encrypted = File.ReadAllBytes(keyFile);
                    byte[] decrypted = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
                    apiKey = Encoding.UTF8.GetString(decrypted).Trim();
                    LogToMainWindow($"✅ API ključ učitan, dužina: {apiKey.Length}");
                }
                else
                {
                    string txtFile = Path.Combine(settingsPath, "pixabay_key.txt");
                    if (File.Exists(txtFile))
                    {
                        apiKey = File.ReadAllText(txtFile).Trim();
                        LogToMainWindow($"✅ API ključ učitan iz TXT, dužina: {apiKey.Length}");
                    }
                }
            }
            catch (Exception ex)
            {
                LogToMainWindow($"❌ Greška pri čitanju API ključa: {ex.Message}");
            }

            if (string.IsNullOrEmpty(apiKey))
            {
                string newKey = null;
                await Dispatcher.InvokeAsync(() =>
                {
                    var dlg = new ApiKeyDialog("Pixabay",
                        "Pixabay API kljuc nije pronadjen.\n\nRegistruj se besplatno na pixabay.com/api,\npa unesi kljuc ovdje.");
                    if (dlg.ShowDialog() == true && !string.IsNullOrEmpty(dlg.ApiKey))
                    {
                        newKey = dlg.ApiKey;
                        try
                        {
                            string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UltraVideoEditor");
                            Directory.CreateDirectory(settingsPath);
                            string keyFile = Path.Combine(settingsPath, "pixabay_key.bin");
                            byte[] data = Encoding.UTF8.GetBytes(newKey);
                            byte[] encrypted = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);
                            File.WriteAllBytes(keyFile, encrypted);
                        }
                        catch (Exception ex) { LogToMainWindow($"❌ Greška pri čuvanju: {ex.Message}"); }
                        apiKey = newKey;
                    }
                });

                if (string.IsNullOrEmpty(apiKey))
                {
                    AnnounceToUser("Pixabay API kljuc nije unesen. Preuzimanje nije moguce.");
                    return null;
                }
            }

            _pixabayApiKey = apiKey;

            for (int attempt = 0; attempt < 2; attempt++)
            {
                try
                {
                    await _apiRateLimiter.WaitAsync(ct);

                    try
                    {
                        ct.ThrowIfCancellationRequested();
                        string searchQ = attempt == 0 ? keywords : _universalKeywords[new Random().Next(_universalKeywords.Count)];
                        string url = mediaType == "video"
                            ? $"https://pixabay.com/api/videos/?key={apiKey}&q={Uri.EscapeDataString(searchQ)}&safesearch=true&per_page=10&video_type=all&duration=1-15"
                            : $"https://pixabay.com/api/?key={apiKey}&q={Uri.EscapeDataString(searchQ)}&image_type=photo&safesearch=true&per_page=5&min_width={minWidth}";

                        string response = await _httpClient.GetStringAsync(url, ct);
                        var json = JObject.Parse(response);
                        var hits = json["hits"] as JArray;

                        if (hits == null || hits.Count == 0) continue;

                        if (mediaType == "video")
                        {
                            foreach (var hit in hits)
                            {
                                var videos = hit["videos"] as JObject;
                                if (videos != null)
                                {
                                    var largeVideo = videos["large"];
                                    if (largeVideo != null)
                                    {
                                        double duration = largeVideo["duration"]?.Value<double>() ?? 999;
                                        string dlUrl = largeVideo["url"]?.ToString();

                                        if (!string.IsNullOrEmpty(dlUrl))
                                        {
                                            string fileName = $"AI_{Guid.NewGuid().ToString().Substring(0, 8)}.mp4";
                                            string fullPath = Path.Combine(GetCurrentProjectFolder(), fileName);

                                            byte[] data = await _httpClient.GetByteArrayAsync(dlUrl, ct);
                                            await File.WriteAllBytesAsync(fullPath, data, ct);

                                            return fullPath;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            var rng = new Random(Guid.NewGuid().GetHashCode());
                            var hit = hits[rng.Next(hits.Count)];
                            string dlUrl = hit["largeImageURL"]?.ToString() ?? hit["webformatURL"]?.ToString();

                            if (!string.IsNullOrEmpty(dlUrl))
                            {
                                string fileName = $"AI_{Guid.NewGuid().ToString().Substring(0, 8)}.jpg";
                                string fullPath = Path.Combine(GetCurrentProjectFolder(), fileName);

                                byte[] data = await _httpClient.GetByteArrayAsync(dlUrl, ct);
                                await File.WriteAllBytesAsync(fullPath, data, ct);

                                return fullPath;
                            }
                        }
                    }
                    finally
                    {
                        _apiRateLimiter.Release();
                    }
                }
                catch (OperationCanceledException) { throw; }
                catch (HttpRequestException ex) when (ex.Message.Contains("429"))
                {
                    await Task.Delay(2000, ct);
                }
                catch (Exception ex)
                {
                    LogToMainWindow($"❌ Greška u attempt {attempt + 1}: {ex.Message}");
                }
            }
            return null;
        }

        private async Task CreateVideo(StoryBoard storyBoard = null)
        {
            var mainWindow = WpfApp.Current.MainWindow as MainWindow;
            if (mainWindow == null) return;

            await Dispatcher.InvokeAsync(() => mainWindow.SaveState());

            // Ukloni stare video/slika klipove I stare tranzicione audio zvukove (🔊)
            // Bez ovoga, svako novo generisanje akumulira stare zvukove
            var itemsToRemove = mainWindow.timelineItems
                .Where(i => i.Type == "Image" || i.Type == "Video" ||
                            (i.Type == "Audio" && i.Name.StartsWith("🔊")))
                .ToList();
            foreach (var item in itemsToRemove)
                mainWindow.timelineItems.Remove(item);

            double cursor = 0;
            var addedItems = new List<TimelineItem>();

            if (chkShowLogo.IsChecked == true && !string.IsNullOrEmpty(txtLogoPath.Text) && File.Exists(txtLogoPath.Text))
            {
                double logoDuration = double.TryParse(txtLogoDuration.Text, out double ld) ? ld : 5;
                var logoItem = new TimelineItem
                {
                    Path = txtLogoPath.Text,
                    Duration = logoDuration,
                    Start = cursor,
                    End = cursor + logoDuration,
                    Name = "Logo kanala - Rastimo uz Iskru",
                    Type = "Image",
                    Volume = 100,
                    TrackIndex = 0,
                    VideoEffect = new VideoEffectData()
                };
                mainWindow.timelineItems.Add(logoItem);
                addedItems.Add(logoItem);
                cursor += logoDuration;
            }

            string songTitle = string.IsNullOrEmpty(txtIntroText.Text) ? "🎵 Nova pjesmica" : txtIntroText.Text;
            double introDuration = 4;
            string introImagePath = await CreateTextImage(songTitle, introDuration, true);
            var introItem = new TimelineItem
            {
                Path = introImagePath,
                Duration = introDuration,
                Start = cursor,
                End = cursor + introDuration,
                Name = $"Naslov: {songTitle}",
                Type = "Image",
                Volume = 100,
                TrackIndex = 0,
                VideoEffect = new VideoEffectData()
            };
            mainWindow.timelineItems.Add(introItem);
            addedItems.Add(introItem);
            cursor += introDuration;

            var sortedSegments = _segments.OrderBy(s => s.StartTime).ToList();
            double maxEnd = cursor;

            foreach (var segment in sortedSegments)
            {
                if (!File.Exists(segment.Path)) continue;

                string ext = Path.GetExtension(segment.Path).ToLower();
                string type = (ext == ".mp4" || ext == ".avi" || ext == ".mov" || ext == ".mkv") ? "Video" : "Image";

                var newItem = new TimelineItem
                {
                    Path = segment.Path,
                    Duration = segment.Duration,
                    Start = cursor + segment.StartTime,
                    End = cursor + segment.StartTime + segment.Duration,
                    Name = segment.Description,
                    Type = type,
                    Volume = 100,
                    TrackIndex = 0,
                    VideoEffect = new VideoEffectData(),
                    AudioDescription = segment.Description
                };
                mainWindow.timelineItems.Add(newItem);
                addedItems.Add(newItem);

                float zoomEnd = 1.03f;
                float xEnd = 5f;
                float yEnd = 3f;

                if (segment.Energy >= 4)
                {
                    zoomEnd = 1.08f;
                    xEnd = 15f;
                    yEnd = 8f;
                }
                else if (segment.Energy <= 2)
                {
                    zoomEnd = 1.02f;
                    xEnd = 3f;
                    yEnd = 2f;
                }

                newItem.Keyframes.Add(new AnimationKeyframe { Time = 0, Zoom = 1.0f, X = 0, Y = 0 });
                newItem.Keyframes.Add(new AnimationKeyframe { Time = segment.Duration * 0.3f, Zoom = 1.02f, X = 3f, Y = 2f });
                newItem.Keyframes.Add(new AnimationKeyframe { Time = segment.Duration * 0.7f, Zoom = zoomEnd - 0.02f, X = xEnd - 5f, Y = yEnd - 3f });
                newItem.Keyframes.Add(new AnimationKeyframe { Time = segment.Duration, Zoom = zoomEnd, X = xEnd, Y = yEnd });

                if (_showLyrics && !string.IsNullOrEmpty(segment.LyricText))
                    mainWindow.AddSubtitle(segment.LyricText, newItem.Start, newItem.End);

                if (newItem.End > maxEnd) maxEnd = newItem.End;
            }

            double totalDuration = maxEnd;

            string outroText = string.IsNullOrEmpty(txtOutroText.Text) ?
                "Autor: Iskra Ajvazi. Muzika i tekst: Iskra Ajvazi. Za još predivnih pesmica, zapratite naš YouTube kanal: @Rastimo uz Iskru" :
                txtOutroText.Text;

            double outroDuration = 7;
            double outroStart = totalDuration - outroDuration;
            if (outroStart < 0) outroStart = totalDuration;
            string outroImagePath = await CreateTextImage(outroText, outroDuration, false);
            var outroItem = new TimelineItem
            {
                Path = outroImagePath,
                Duration = outroDuration,
                Start = outroStart,
                End = outroStart + outroDuration,
                Name = "Odjavni tekst",
                Type = "Image",
                Volume = 100,
                TrackIndex = 0,
                VideoEffect = new VideoEffectData()
            };
            mainWindow.timelineItems.Add(outroItem);
            addedItems.Add(outroItem);

            var audioItem = mainWindow.timelineItems.FirstOrDefault(i => i.Type == "Audio");
            if (audioItem != null)
            {
                if (!string.IsNullOrEmpty(_ambientAudioPath) && File.Exists(_ambientAudioPath))
                {
                    audioItem.Path = _ambientAudioPath;
                    LogToMainWindow("🎵 Koristim miksani audio sa ambijentalnim zvukovima");
                }
                audioItem.Start = 0;
                audioItem.End = totalDuration;
                audioItem.Duration = totalDuration;
            }

            // VAŽNO: Iteriramo SAMO kroz video/slika klipove (snimak liste prije dodavanja tranzicija)
            // Ako bismo iterirali kroz addedItems i u petlji dodavali u addedItems,
            // dobijamo beskonačan loop jer svaka tranzicija generise novu tranziciju.
            var videoImageItems = addedItems
                .Where(i => i.Type == "Video" || i.Type == "Image")
                .OrderBy(i => i.Start)
                .ToList();

            for (int i = 0; i < videoImageItems.Count - 1; i++)
            {
                var currentItem = videoImageItems[i];
                var nextItem = videoImageItems[i + 1];
                double gap = nextItem.Start - currentItem.End;

                int currentEnergy = i < _segments.Count ? _segments[i]?.Energy ?? 3 : 3;
                int nextEnergy = i + 1 < _segments.Count ? _segments[i + 1]?.Energy ?? 3 : 3;
                // Koristimo prosječnu energiju tranzicije
                int transEnergy = (currentEnergy + nextEnergy) / 2;
                double fadeDuration = transEnergy >= 4 ? 0.3 : 0.4;

                // Tranzicioni zvuk: dodaj samo na energičnijim tranzicijama (>=3)
                // i variramo tip da ne bude monotono
                bool addTransitionSound = _enableTransitionSounds && transEnergy >= 3;
                string soundType = transEnergy >= 4 ? "whoosh" : "pop";
                int transitionVolume = transEnergy switch
                {
                    5 => 85,
                    4 => 75,
                    3 => 65,
                    _ => 55
                };
                double transitionDuration = transEnergy >= 4 ? 0.55 : 0.4;

                if (gap > 0.1)
                {
                    AddSmoothFadeOut(currentItem, fadeDuration);
                    AddSmoothFadeIn(nextItem, fadeDuration);

                    if (addTransitionSound)
                    {
                        string transSound = await GetTransitionSound(_tempVideoFolder, soundType);
                        if (transSound != null && File.Exists(transSound))
                        {
                            mainWindow.timelineItems.Add(new TimelineItem
                            {
                                Path = transSound,
                                Duration = transitionDuration,
                                Start = currentItem.End - 0.1,
                                End = currentItem.End - 0.1 + transitionDuration,
                                Name = $"🔊 {(soundType == "whoosh" ? "Whoosh" : "Pop")}",
                                Type = "Audio",
                                Volume = transitionVolume,
                                TrackIndex = 1
                            });
                        }
                    }
                }
                else
                {
                    AddCrossfadeWithEnergy(currentItem, nextItem, fadeDuration, transEnergy);

                    if (addTransitionSound)
                    {
                        string popSound = await GetTransitionSound(_tempVideoFolder, "pop");
                        if (popSound != null && File.Exists(popSound))
                        {
                            mainWindow.timelineItems.Add(new TimelineItem
                            {
                                Path = popSound,
                                Duration = transitionDuration,
                                Start = currentItem.End - 0.1,
                                End = currentItem.End - 0.1 + transitionDuration,
                                Name = "🔊 Pop",
                                Type = "Audio",
                                Volume = transitionVolume,
                                TrackIndex = 1
                            });
                        }
                    }
                }
            }

            await Dispatcher.InvokeAsync(() => mainWindow.UpdateTimelineDisplay());

            int segmentsCount = _segments?.Count ?? 0;
            double segmentsTotal = _segments?.Sum(s => s.Duration) ?? 0;

            WpfMessageBox.Show($"AI Video Creator završio!\n\nDodato: {segmentsCount} klipova\nTrajanje klipova: {FormatTime(segmentsTotal)} ({segmentsTotal:F1}s)\nTrajanje audio: {FormatTime(totalDuration)} ({totalDuration:F1}s)\n\nSada možete renderovati video (Ctrl+R).", "Završeno", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = true;
            Close();
        }

        private void AddSmoothFadeOut(TimelineItem item, double duration)
        {
            double startTime = Math.Max(0, item.Duration - duration);
            item.Keyframes.Add(new AnimationKeyframe { Time = startTime, Opacity = 1 });
            item.Keyframes.Add(new AnimationKeyframe { Time = item.Duration, Opacity = 0 });
        }

        private void AddSmoothFadeIn(TimelineItem item, double duration)
        {
            item.Keyframes.Add(new AnimationKeyframe { Time = 0, Opacity = 0 });
            item.Keyframes.Add(new AnimationKeyframe { Time = duration, Opacity = 1 });
        }

        private void AddCrossfadeWithEnergy(TimelineItem currentItem, TimelineItem nextItem, double duration, int nextEnergy)
        {
            double startFade = Math.Max(0, currentItem.Duration - duration);
            currentItem.Keyframes.Add(new AnimationKeyframe { Time = startFade, Opacity = 1 });
            currentItem.Keyframes.Add(new AnimationKeyframe { Time = currentItem.Duration, Opacity = 0 });

            double fadeInDuration = nextEnergy >= 4 ? duration * 0.6 : duration;
            nextItem.Keyframes.Add(new AnimationKeyframe { Time = 0, Opacity = 0 });
            nextItem.Keyframes.Add(new AnimationKeyframe { Time = fadeInDuration, Opacity = 1 });
        }

        private async Task<string> CreateTextImage(string text, double duration, bool isIntro = false)
        {
            string tempPath = Path.Combine(Path.GetTempPath(), $"text_{Guid.NewGuid()}.png");

            await Task.Run(() =>
            {
                using (var surface = SKSurface.Create(new SKImageInfo(1920, 1080)))
                {
                    var canvas = surface.Canvas;
                    canvas.Clear(isIntro ? new SKColor(46, 125, 50) : SKColors.Black);

                    using (var paint = new SKPaint())
                    {
                        paint.Color = SKColors.White;
                        paint.TextSize = isIntro ? 96 : 56;
                        paint.IsAntialias = true;
                        paint.TextAlign = SKTextAlign.Center;

                        if (isIntro)
                            paint.Typeface = SKTypeface.FromFamilyName("Arial", SKFontStyleWeight.Bold, SKFontStyleWidth.Normal, SKFontStyleSlant.Upright);

                        var words = text.Split(' ');
                        var lines = new List<string>();
                        var currentLine = "";
                        int maxCharsPerLine = isIntro ? 20 : 40;

                        foreach (var word in words)
                        {
                            var testLine = string.IsNullOrEmpty(currentLine) ? word : currentLine + " " + word;
                            if (testLine.Length > maxCharsPerLine)
                            {
                                lines.Add(currentLine);
                                currentLine = word;
                            }
                            else
                            {
                                currentLine = testLine;
                            }
                        }
                        if (!string.IsNullOrEmpty(currentLine)) lines.Add(currentLine);

                        float startY = 540 - (lines.Count - 1) * (isIntro ? 50 : 35);
                        float y = startY;
                        foreach (var line in lines)
                        {
                            canvas.DrawText(line, 960, y, paint);
                            y += isIntro ? 80 : 60;
                        }
                    }

                    using (var image = surface.Snapshot())
                    using (var data = image.Encode(SKEncodedImageFormat.Png, 100))
                    using (var stream = File.OpenWrite(tempPath))
                    {
                        data.SaveTo(stream);
                    }
                }
            });

            return tempPath;
        }

        private string FormatTime(double seconds) => TimeSpan.FromSeconds(seconds).ToString(@"mm\:ss");

        private string GetPixabayApiKey()
        {
            try
            {
                string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UltraVideoEditor");
                string keyFile = Path.Combine(settingsPath, "pixabay_key.bin");

                if (File.Exists(keyFile))
                {
                    byte[] encrypted = File.ReadAllBytes(keyFile);
                    byte[] decrypted = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
                    return Encoding.UTF8.GetString(decrypted).Trim();
                }

                string txtFile = Path.Combine(settingsPath, "pixabay_key.txt");
                if (File.Exists(txtFile))
                    return File.ReadAllText(txtFile).Trim();
            }
            catch (Exception ex)
            {
                AnnounceToUser("Greska pri citanju Pixabay kljuca: " + ex.Message);
            }
            return null;
        }

        private void SavePixabayApiKey(string key)
        {
            try
            {
                string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UltraVideoEditor");
                Directory.CreateDirectory(settingsPath);
                string keyFile = Path.Combine(settingsPath, "pixabay_key.bin");
                byte[] data = Encoding.UTF8.GetBytes(key);
                byte[] encrypted = ProtectedData.Protect(data, null, DataProtectionScope.CurrentUser);
                File.WriteAllBytes(keyFile, encrypted);
            }
            catch (Exception ex)
            {
                AnnounceToUser("Greska pri cuvanju Pixabay kljuca: " + ex.Message);
            }
        }

        private string GetCurrentProjectFolder()
        {
            if (WpfApp.Current.MainWindow is MainWindow mainWin) return mainWin.GetCurrentProjectFolder();
            return Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        }

        private void LogToMainWindow(string message)
        {
            try
            {
                Dispatcher.Invoke(() =>
                {
                    if (WpfApp.Current.MainWindow is MainWindow mainWin)
                        mainWin.LogMessage(message, true);
                });
            }
            catch { }
        }

        private void AnnounceToUser(string message, int progressPercent = -1)
        {
            Dispatcher.Invoke(() =>
            {
                txtOllamaStatus.Text = message;
                if (progressPercent >= 0)
                {
                    prgProgress.Value = progressPercent;
                    txtProgress.Text = $"{progressPercent}% - {message}";
                }
                var peer = UIElementAutomationPeer.FromElement(txtOllamaStatus);
                peer?.RaiseAutomationEvent(AutomationEvents.LiveRegionChanged);
            });
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (_isRunning) { _cts?.Cancel(); AnnounceToUser("Otkazivanje..."); btnCancel.Content = "Otkazivanje..."; btnCancel.IsEnabled = false; }
            else { DialogResult = false; Close(); }
        }
    }

    #region Helper Classes

    public class StoryScene
    {
        public int SceneNumber { get; set; }
        public string Description { get; set; }
        public string Emotion { get; set; }
        public int Energy { get; set; }
        public string Characters { get; set; }
        public string Action { get; set; }
        public string Location { get; set; }
        public string Keywords { get; set; }
        public string AmbientSound { get; set; }
        public double StartTime { get; set; }
        public double Duration { get; set; }
        public string AmbientPath { get; set; }
    }

    public class StoryBoard
    {
        public List<StoryScene> Scenes { get; set; }
        public string MainCharacter { get; set; }
        public string OverallTheme { get; set; }
    }

    public class TimelineSegment
    {
        public string Path { get; set; }
        public double Duration { get; set; }
        public double StartTime { get; set; }
        public string Description { get; set; }
        public string LyricText { get; set; }
        public string AmbientSoundPath { get; set; }
        public string VoiceNarrationPath { get; set; }
        public int Energy { get; set; }
        public string Emotion { get; set; }
    }

    public class SongAnalysis
    {
        [Newtonsoft.Json.JsonProperty("context")]
        public string Context { get; set; }
        [Newtonsoft.Json.JsonProperty("mood")]
        public string Mood { get; set; }
        [Newtonsoft.Json.JsonProperty("theme")]
        public string Theme { get; set; }
        [Newtonsoft.Json.JsonProperty("visual_style")]
        public string VisualStyle { get; set; }
        [Newtonsoft.Json.JsonProperty("main_subject")]
        public string MainSubject { get; set; }
        [Newtonsoft.Json.JsonProperty("season")]
        public string Season { get; set; }
        [Newtonsoft.Json.JsonProperty("setting")]
        public string Setting { get; set; }
    }

    public class SceneKeywords
    {
        [Newtonsoft.Json.JsonProperty("line")]
        public int Line { get; set; }
        [Newtonsoft.Json.JsonProperty("keywords")]
        public string Keywords { get; set; }
        [Newtonsoft.Json.JsonProperty("ambient")]
        public string Ambient { get; set; }
    }

    #endregion

} // end class AIVideoCreator

 // end namespace UltraVideoEditor